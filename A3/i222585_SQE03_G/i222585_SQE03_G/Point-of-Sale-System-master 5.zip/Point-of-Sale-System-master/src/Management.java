import java.io.*;
import java.util.*;
import java.text.*;
import java.util.logging.Logger;
import java.util.logging.Level;

public class Management {

    private static final Logger LOGGER = Logger.getLogger(Management.class.getName());
    private static final String USER_DATABASE = "Database/userDatabase.txt";

    public Management() {
        if (System.getProperty("os.name").startsWith("W") || System.getProperty("os.name").startsWith("w")) {
            // USER_DATABASE = "..\\Database\\userDatabase.txt"; // Uncomment if path needs to be adjusted for Windows
        }
    }

    // Helper method to read lines from a file
    private List<String> readFileLines(String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    // Helper method to write lines to a file
    private void writeFileLines(String filePath, List<String> lines) throws IOException {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(filePath, false)))) {
            for (String line : lines) {
                writer.println(line);
            }
        }
    }

    // Checks if a user exists in the database by phone number
    public Boolean checkUser(Long phone) {
        try {
            List<String> lines = readFileLines(USER_DATABASE);
            for (String line : lines) {
                String[] parts = line.split(" ");
                try {
                    long nextPhone = Long.parseLong(parts[0]);
                    if (nextPhone == phone) {
                        return true;
                    }
                } catch (NumberFormatException e) {
                    LOGGER.log(Level.WARNING, "Skipping invalid phone number format in database: " + parts[0], e);
                }
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Cannot open or read user database", e);
        }
        return false;
    }

    // Retrieves the latest return items with outstanding returns for a user
    public List<ReturnItem> getLatestReturnDate(Long phone) {
        List<ReturnItem> returnList = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");

        try {
            List<String> lines = readFileLines(USER_DATABASE);
            for (String line : lines) {
                String[] parts = line.split(" ");
                try {
                    long nextPhone = Long.parseLong(parts[0]);
                    if (nextPhone == phone && parts.length > 1) {
                        for (int i = 1; i < parts.length; i++) {
                            String[] itemParts = parts[i].split(",");
                            if ("false".equalsIgnoreCase(itemParts[2])) {
                                Date returnDate = formatter.parse(itemParts[1]);
                                int daysOverdue = daysBetween(returnDate);
                                returnList.add(new ReturnItem(Integer.parseInt(itemParts[0]), daysOverdue));
                            }
                        }
                    }
                } catch (NumberFormatException | ParseException e) {
                    LOGGER.log(Level.WARNING, "Error parsing data for phone: " + phone, e);
                }
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Cannot open or read user database", e);
        }

        return returnList;
    }

    // Helper method to calculate days between a given date and today
    private static int daysBetween(Date date) {
        Calendar day1 = Calendar.getInstance();
        day1.setTime(date);
        Calendar today = Calendar.getInstance();

        long diffMillis = today.getTimeInMillis() - day1.getTimeInMillis();
        return (int) (diffMillis / (1000 * 60 * 60 * 24));
    }

    // Creates a new user entry in the user database
    public boolean createUser(Long phone) {
        String strPhone = Long.toString(phone);
        List<String> lines;
        try {
            lines = readFileLines(USER_DATABASE);
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error reading user database to create new user", e);
            return false;
        }

        lines.add(strPhone);
        try {
            writeFileLines(USER_DATABASE, lines);
            return true;
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Cannot write new user to user database", e);
            return false;
        }
    }

    // Adds rental items to an existing user in the user database
    public void addRental(long phone, List<Item> rentalList) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
        String dateFormat = formatter.format(date);

        List<String> lines;
        try {
            lines = readFileLines(USER_DATABASE);
            boolean userFound = false;

            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] parts = line.split(" ");
                try {
                    long nextPhone = Long.parseLong(parts[0]);
                    if (nextPhone == phone) {
                        userFound = true;
                        StringBuilder modifiedLine = new StringBuilder(line);
                        for (Item item : rentalList) {
                            modifiedLine.append(" ").append(item.getItemID()).append(",").append(dateFormat).append(",false");
                        }
                        lines.set(i, modifiedLine.toString());
                    }
                } catch (NumberFormatException e) {
                    LOGGER.log(Level.WARNING, "Skipping invalid phone number format in database: " + parts[0], e);
                }
            }

            if (!userFound) {
                StringBuilder newUserLine = new StringBuilder(phone + "");
                for (Item item : rentalList) {
                    newUserLine.append(" ").append(item.getItemID()).append(",").append(dateFormat).append(",false");
                }
                lines.add(newUserLine.toString());
            }

            writeFileLines(USER_DATABASE, lines);

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error handling rental addition in user database", e);
        }
    }

    // Updates rental status for returned items in the user database
    public void updateRentalStatus(long phone, List<ReturnItem> returnedList) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy");
        String dateFormat = formatter.format(date);

        List<String> lines;
        try {
            lines = readFileLines(USER_DATABASE);

            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] parts = line.split(" ");
                try {
                    long nextPhone = Long.parseLong(parts[0]);
                    if (nextPhone == phone) {
                        StringBuilder modifiedLine = new StringBuilder(parts[0]);

                        for (int j = 1; j < parts.length; j++) {
                            String[] itemParts = parts[j].split(",");
                            boolean returned = "true".equalsIgnoreCase(itemParts[2]);

                            if (!returned) {
                                boolean isReturnedNow = returnedList.stream()
                                        .anyMatch(item -> item.getItemID() == Integer.parseInt(itemParts[0]));
                                if (isReturnedNow) {
                                    modifiedLine.append(" ").append(itemParts[0]).append(",").append(dateFormat).append(",true");
                                } else {
                                    modifiedLine.append(" ").append(parts[j]);
                                }
                            } else {
                                modifiedLine.append(" ").append(parts[j]);
                            }
                        }
                        lines.set(i, modifiedLine.toString());
                    }
                } catch (NumberFormatException e) {
                    LOGGER.log(Level.WARNING, "Skipping invalid phone number format in database: " + parts[0], e);
                }
            }

            writeFileLines(USER_DATABASE, lines);

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error updating rental status in user database", e);
        }
    }
}
