public class Employee {

    // Constants for validation
    private static final int MIN_PASSWORD_LENGTH = 6;
    private static final int MAX_PASSWORD_LENGTH = 20;
    private static final String VALID_POSITION_PATTERN = "Admin|User"; // example positions

    // attributes
    private String username;
    private String name;
    private String position;
    private String password;

    // constructor with validation
    public Employee(String username, String name, String position, String password) {
        if (!isValidUsername(username)) {
            throw new IllegalArgumentException("Invalid username format.");
        }
        if (!isValidPassword(password)) {
            throw new IllegalArgumentException("Password must be between " + MIN_PASSWORD_LENGTH + " and " + MAX_PASSWORD_LENGTH + " characters.");
        }
        if (!isValidPosition(position)) {
            throw new IllegalArgumentException("Invalid position. Must be either 'Admin' or 'User'.");
        }

        this.username = username;
        this.name = name;
        this.position = position;
        this.password = hashPassword(password); // Hashing the password for security
    }

    // Getter methods
    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public String getPassword() {
        return password;
    }

    // Consolidated setter method for updating employee info
    public void updateEmployeeInfo(String name, String position, String password) {
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
        if (position != null && !position.isEmpty() && isValidPosition(position)) {
            this.position = position;
        }
        if (password != null && !password.isEmpty() && isValidPassword(password)) {
            this.password = hashPassword(password); // Hashing the new password
        }
    }

    // Private helper methods for validation
    private boolean isValidUsername(String username) {
        return username != null && !username.trim().isEmpty();
    }

    private boolean isValidPassword(String password) {
        return password != null && password.length() >= MIN_PASSWORD_LENGTH && password.length() <= MAX_PASSWORD_LENGTH;
    }

    private boolean isValidPosition(String position) {
        return position != null && position.matches(VALID_POSITION_PATTERN);
    }

    // Simple password hashing (you can replace this with a more secure method)
    private String hashPassword(String password) {
        // Simple example: You could replace this with a stronger hashing algorithm like bcrypt
        return Integer.toHexString(password.hashCode());  // Using hashCode for simplicity (not secure)
    }
}
