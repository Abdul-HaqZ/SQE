public class ReturnItem {

    // Attributes
    private int itemID;
    private int daysSinceReturn;
    
    // Constant for the maximum allowable return days
    private static final int MAX_RETURN_DAYS = 30;

    // Constructor
    public ReturnItem(int itemID, int daysSinceReturn) {
        this.itemID = itemID;
        this.daysSinceReturn = daysSinceReturn;
    }

    // Getters
    public int getItemID() {
        return itemID;
    }

    public int getDays() {
        return daysSinceReturn;
    }

    // Method to check if the return is valid based on days since return
    public boolean isReturnValid() {
        return daysSinceReturn <= MAX_RETURN_DAYS;
    }
}
