import java.io.*;
import java.util.*;
import java.util.logging.*;

abstract class PointOfSale {
  // Attributes
  public double totalPrice = 0;
  private static float discount = 0.90f;
  public boolean unixOS = true; 
  public double tax = 1.06;
  public boolean returnSale = true;
  public static String couponNumber = "Database/couponNumber.txt";
  public static String tempFile = "Database/temp.txt";

  Inventory inventory = Inventory.getInstance();
  public List<Item> databaseItem = new ArrayList<Item>();
  public List<Item> transactionItem = new ArrayList<Item>();
  
  private static final Logger logger = Logger.getLogger(PointOfSale.class.getName());

  // Start new POS transaction
  public boolean startNew(String databaseFile) {
    return inventory.accessInventory(databaseFile, databaseItem);
  }

  // Enter item into the transaction list
  public boolean enterItem(int itemID, int amount) {
    detectSystem();
    for (Item item : databaseItem) {
      if (item.getItemID() == itemID) {
        transactionItem.add(new Item(itemID, item.getItemName(), item.getPrice(), amount));
        return true;
      }
    }
    return false;
  }

  // Update the total price of the current transaction
  public double updateTotal() {
    Item lastItem = transactionItem.get(transactionItem.size() - 1);
    totalPrice += lastItem.getPrice() * lastItem.getAmount();
    return totalPrice;
  }

  // Validate coupon code
  public boolean coupon(String couponNo) {
    List<String> coupons = readCoupons();
    if (coupons.contains(couponNo)) {
      totalPrice *= discount;
      return true;
    }
    return false;
  }

  // Read coupon numbers from file
  private List<String> readCoupons() {
    List<String> coupons = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(couponNumber))) {
      String line;
      while ((line = reader.readLine()) != null) {
        coupons.add(line);
      }
    } catch (IOException e) {
      logger.warning("Error reading coupons file: " + e.getMessage());
    }
    return coupons;
  }

  // Create temporary file entry for an item
  public void createTemp(int id, int amount) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile, true))) {
      writer.write(id + " " + amount);
      writer.newLine();
    } catch (IOException e) {
      logger.severe("Error creating temporary file: " + e.getMessage());
    }
  }

  // Remove an item from the transaction list
  public boolean removeItems(int itemID) {
    for (int i = 0; i < transactionItem.size(); i++) {
      if (transactionItem.get(i).getItemID() == itemID) {
        totalPrice -= transactionItem.get(i).getPrice() * transactionItem.get(i).getAmount();
        deleteTempItem(itemID);
        transactionItem.remove(i);
        if (transactionItem.isEmpty()) {
          new File(tempFile).delete();
        }
        return true;
      }
    }
    return false;
  }

  // Detect system type (Windows or Unix)
  public void detectSystem() {
    if (System.getProperty("os.name").startsWith("W") || System.getProperty("os.name").startsWith("w")) {
      // Handle Windows-specific behavior here
    }
  }

  // Validate credit card number
  public boolean creditCard(String card) {
    if (card.length() != 16) return false;
    return card.chars().allMatch(Character::isDigit);
  }

  // Get the last added item
  public Item lastAddedItem() {
    return transactionItem.get(transactionItem.size() - 1);
  }

  // Get the current cart
  public List<Item> getCart() {
    return transactionItem;
  }

  // Get the size of the cart
  public int getCartSize() {
    return transactionItem.size();
  }

  // Abstract methods to be implemented by subclasses
  public abstract double endPOS(String textFile);
  public abstract void deleteTempItem(int id);
  public abstract void retrieveTemp(String textFile);
  
  // Helper Methods for File Handling
  
  // Read file lines into a list of strings
  protected List<String> readFileLines(String fileName) {
    List<String> lines = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
      String line;
      while ((line = reader.readLine()) != null) {
        lines.add(line);
      }
    } catch (IOException e) {
      logger.warning("Error reading file " + fileName + ": " + e.getMessage());
    }
    return lines;
  }

  // Write lines to a file
  protected void writeFileLines(String fileName, List<String> lines) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
      for (String line : lines) {
        writer.write(line);
        writer.newLine();
      }
    } catch (IOException e) {
      logger.severe("Error writing to file " + fileName + ": " + e.getMessage());
    }
  }

public abstract Object getTotal();
}
