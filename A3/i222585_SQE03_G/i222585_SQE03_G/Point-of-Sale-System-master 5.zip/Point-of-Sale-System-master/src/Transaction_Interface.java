import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Transaction_Interface extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 80;
    private static final String SALE_DATABASE_FILE = "Database/itemDatabase.txt";
    private static final String RENTAL_DATABASE_FILE = "Database/rentalDatabase.txt";
    
    private PointOfSale transaction;
    private Management management = new Management();
    
    private JButton addItem;
    private JButton removeItem;
    private JButton endTransaction;
    private JButton cancelTransaction;
    private String phone = "";
    private long phoneNum;
    private JTextArea transactionDialog;
    
    public boolean returnOrNot;
    private String databaseFile;
    
    String operation = "";
    
    JScrollPane scroll;
    
    private int choice = 3;
    
    public Transaction_Interface(String operation) {
        super("SG Technologies - Transaction View");
        setLayout(null);
        
        this.operation = operation;
        
        Toolkit tk = Toolkit.getDefaultToolkit();
        int xSize = ((int) tk.getScreenSize().getWidth());
        int ySize = ((int) tk.getScreenSize().getHeight());
        
        setSize(xSize, ySize);
        
        setupButtons(xSize, ySize);
        setupTransactionDialog(xSize, ySize);
        
        initializeTransaction();
    }
    
    private void setupButtons(int xSize, int ySize) {
        addItem = createButton("Add Item", xSize * 4 / 5, ySize / 6);
        removeItem = createButton("Remove Item", xSize * 4 / 5, ySize * 2 / 6);
        endTransaction = createButton("End", xSize * 4 / 5, ySize * 3 / 6);
        cancelTransaction = createButton("Cancel", xSize * 4 / 5, ySize * 4 / 6);
        
        addItem.addActionListener(this);
        removeItem.addActionListener(this);
        endTransaction.addActionListener(this);
        cancelTransaction.addActionListener(this);
    }
    
    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(button);
        return button;
    }
    
    private void setupTransactionDialog(int xSize, int ySize) {
        transactionDialog = new JTextArea();
        transactionDialog.setBackground(Color.white);
        transactionDialog.setForeground(Color.black);
        transactionDialog.setEditable(false);
        Font font = transactionDialog.getFont();
        float size = font.getSize() + 5.0f;
        transactionDialog.setFont(font.deriveFont(size));
        
        scroll = new JScrollPane(transactionDialog, 
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBounds(xSize / 16, ySize / 16, 3 * xSize / 5, 4 * ySize / 5);
        add(scroll);
    }
    
    private void initializeTransaction() {
        if (operation.equals("Sale")) {
            returnOrNot = false;
            transaction = new POS();
            databaseFile = SALE_DATABASE_FILE;
        } else if (operation.equals("Rental")) {
            returnOrNot = false;
            getCustomerPhone();
            databaseFile = RENTAL_DATABASE_FILE;
            transaction = new POR(phoneNum);
        } else if (operation.equals("Return")) {
            returnOrNot = true;
            handleReturnOperation();
        }
        
        transaction.startNew(databaseFile);
        
        if (operation.equals("Return") && choice != 0) {
            databaseFile = "";
            this.operation = "Unsatisfactory";
        }
    }
    
    private void handleReturnOperation() {
        Object[] options = {"Rented Items", "Unsatisfactory items"};
        
        choice = JOptionPane.showOptionDialog(null, 
                "Returning rented items or unsatisfactory items?", 
                "Choose an option", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                options, 
                options[0]);
        
        if (choice == 0) {
            databaseFile = RENTAL_DATABASE_FILE;
            getCustomerPhone();
            transaction = new POH(phoneNum);
            transaction.returnSale = false;
        } else {
            transaction = new POH();
            databaseFile = SALE_DATABASE_FILE;
            transaction.returnSale = true;
            phone = "0000000000";
        }
    }
    
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == addItem) {
            openItemEntryDialog(true);
        }
        if (event.getSource() == removeItem) {
            openItemEntryDialog(false);
        }
        if (event.getSource() == endTransaction) {
            endTransaction();
        }
        if (event.getSource() == cancelTransaction) {
            cancelTransaction();
        }
    }
    
    private void openItemEntryDialog(boolean isAdding) {
        EnterItem_Interface enterItem = new EnterItem_Interface(transaction, isAdding, transactionDialog, operation, choice);
        enterItem.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        enterItem.setVisible(true);
    }
    
    private void endTransaction() {
        if (transaction.getCartSize() > 0) {
            String coupon = "";
            if (operation.equals("Sale")) {
                coupon = JOptionPane.showInputDialog("Enter coupon code if user has one");
                if (!coupon.equals("") && !transaction.coupon(coupon)) {
                    JOptionPane.showMessageDialog(null, "Invalid coupon");
                }
            }
            
            if (operation.equals("Unsatisfactory")) {
                transaction.endPOS(databaseFile);
                JOptionPane.showMessageDialog(null, "Returning items is complete");
                navigateToCashier();
            } else {
                Payment_Interface payment = new Payment_Interface(transaction, databaseFile, operation, phone, returnOrNot);
                payment.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                payment.setVisible(true);
                
                this.setVisible(false);
                this.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Cart is currently empty. Please add items before ending transaction");
        }
    }
    
    private void cancelTransaction() {
        JOptionPane.showMessageDialog(null, "Transaction Has Been Cancelled");
        navigateToCashier();
    }
    
    private void navigateToCashier() {
        POSSystem sys = new POSSystem();
        Cashier_Interface cashier = new Cashier_Interface(sys);
        cashier.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cashier.setVisible(true);
        
        this.setVisible(false);
        this.dispose();
    }
    
    private void getCustomerPhone() {
        phone = JOptionPane.showInputDialog("Please enter customer's phone number");
        while ((phoneNum = Long.parseLong(phone)) > 9999999999l || (phoneNum < 1000000000l)) {
            JOptionPane.showMessageDialog(null, "Invalid phone number. Please enter again");
            phone = JOptionPane.showInputDialog("Please enter customer's phone number");
        }
        if (!management.checkUser(phoneNum)) {
            if (management.createUser(phoneNum)) {
                JOptionPane.showMessageDialog(null, "New customer was registered");
            } else {
                JOptionPane.showMessageDialog(null, "New customer couldn't be registered");
            }
        }
    }
}
