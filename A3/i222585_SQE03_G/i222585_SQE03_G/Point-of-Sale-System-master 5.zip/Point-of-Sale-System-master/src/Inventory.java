import java.io.*;
import java.util.*;
import java.util.logging.Logger;  // Correct import

public class Inventory {
    private static Inventory uniqueInstance = null;

    private static final Logger LOGGER = Logger.getLogger(Inventory.class.getName());  // Correct Logger usage

    private Inventory() {}

    public static synchronized Inventory getInstance() {
        if (uniqueInstance == null) {
            uniqueInstance = new Inventory();
        }
        return uniqueInstance;
    }

    // Method to access inventory from a file
    public boolean accessInventory(String databaseFile, List<Item> databaseItem) {
        boolean ableToOpen = true;
        try {
            loadInventoryFromFile(databaseFile, databaseItem);
        } catch (IOException e) {
            LOGGER.severe("Error accessing inventory file: " + e.getMessage());  // Correct logging method
            ableToOpen = false;
        }
        return ableToOpen;
    }

    private void loadInventoryFromFile(String databaseFile, List<Item> databaseItem) throws IOException {
        try (BufferedReader textReader = new BufferedReader(new FileReader(databaseFile))) {
            String line;
            while ((line = textReader.readLine()) != null) {
                String[] lineSort = line.split(" ");
                databaseItem.add(new Item(Integer.parseInt(lineSort[0]), lineSort[1], Float.parseFloat(lineSort[2]), Integer.parseInt(lineSort[3])));
            }
        }
    }

    // Method to update inventory and handle transactions
    public void updateInventory(String databaseFile, List<Item> transactionItem, List<Item> databaseItem, boolean takeFromInventory) {
        Map<Integer, Item> itemLookup = createItemLookup(databaseItem);
        
        for (Item transaction : transactionItem) {
            Item dbItem = itemLookup.get(transaction.getItemID());
            if (dbItem != null) {
                int newAmount = calculateNewAmount(dbItem, transaction, takeFromInventory);
                dbItem.updateAmount(newAmount);
            }
        }

        // Save updated inventory to file
        try {
            writeInventoryToFile(databaseFile, databaseItem);
        } catch (IOException e) {
            LOGGER.severe("Error writing inventory to file: " + e.getMessage());  // Correct logging method
        }
    }

    private Map<Integer, Item> createItemLookup(List<Item> databaseItem) {
        Map<Integer, Item> itemLookup = new HashMap<>();
        for (Item item : databaseItem) {
            itemLookup.put(item.getItemID(), item);
        }
        return itemLookup;
    }

    private int calculateNewAmount(Item dbItem, Item transaction, boolean takeFromInventory) {
        if (takeFromInventory) {
            return dbItem.getAmount() - transaction.getAmount();
        } else {
            return dbItem.getAmount() + transaction.getAmount();
        }
    }

    private void writeInventoryToFile(String databaseFile, List<Item> databaseItem) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(databaseFile, false))) {
            for (Item item : databaseItem) {
                writer.write(item.getItemID() + " " + item.getItemName() + " " + item.getPrice() + " " + item.getAmount());
                writer.newLine();
            }
        }
    }
}
