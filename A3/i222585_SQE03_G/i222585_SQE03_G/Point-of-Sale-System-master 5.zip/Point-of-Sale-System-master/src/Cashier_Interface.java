import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Cashier_Interface extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // Constants for button dimensions and layout
    private static final int BUTTON_HEIGHT = 100;

    private JButton saleButton;
    private JButton rentalButton;
    private JButton returnButton;
    private JButton logOutButton;
    private Transaction_Interface transaction;
    private POSSystem system1;

    public Cashier_Interface(POSSystem system2) {
        super("SG Technologies - Cashier View");
        setLayout(null);

        Toolkit tk = Toolkit.getDefaultToolkit();
        int xSize = ((int) tk.getScreenSize().getWidth());
        int ySize = ((int) tk.getScreenSize().getHeight());
        setSize(xSize, ySize);

        this.system1 = system2;

        // Initialize buttons
        saleButton = createButton("Sale", 0, ySize / 5, xSize, BUTTON_HEIGHT);
        rentalButton = createButton("Rental", 0, ySize * 2 / 5, xSize, BUTTON_HEIGHT);
        returnButton = createButton("Returns", 0, ySize * 3 / 5, xSize, BUTTON_HEIGHT);
        logOutButton = createButton("Log Out", 0, ySize * 4 / 5, xSize, BUTTON_HEIGHT);

        checkAndRestoreTransaction();
    }

    // Helper method to create buttons
    private JButton createButton(String text, int x, int y, int width, int height) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.addActionListener(this);
        add(button);
        return button;
    }

    // Method to check and restore an unfinished transaction
    private void checkAndRestoreTransaction() {
        POSSystem system = new POSSystem();
        if (system.checkTemp()) {
            int choice = JOptionPane.showOptionDialog(
                null,
                "System was able to restore an unfinished transaction. Would you like to retrieve it?",
                "Choose an option",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Yes", "No"},
                "No"
            );

            if (choice == JOptionPane.NO_OPTION) {
                Management management = new Management();
                handleUserInputAndRestoreTransaction(management, system);
            }
        }
    }

    // Helper method for handling user input during transaction restoration
    private void handleUserInputAndRestoreTransaction(Management management, POSSystem system) {
        long phoneNum;
        String phone = JOptionPane.showInputDialog("Please enter customer's phone number");
        while ((phoneNum = Long.parseLong(phone)) > 9999999999L || phoneNum < 1000000000L) {
            JOptionPane.showMessageDialog(null, "Invalid phone number. Please enter again");
            phone = JOptionPane.showInputDialog("Please enter customer's phone number");
        }
        if (!management.checkUser(phoneNum)) {
            if (management.createUser(phoneNum)) {
                JOptionPane.showMessageDialog(null, "New customer was registered");
            } else {
                JOptionPane.showMessageDialog(null, "New customer couldn't be registered");
            }
        }

        String operation = system.continueFromTemp(phoneNum);
        openTransaction(operation);
    }

    // Helper method to open a transaction
    private void openTransaction(String operation) {
        transaction = new Transaction_Interface(operation);
        transaction.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        transaction.setVisible(true);
        this.setVisible(false);
        dispose();
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == saleButton) {
            handleSaleAction();
        } else if (event.getSource() == rentalButton) {
            handleRentalAction();
        } else if (event.getSource() == returnButton) {
            handleReturnAction();
        } else if (event.getSource() == logOutButton) {
            handleLogOutAction();
        }
    }

    // Separate methods for each button action
    private void handleSaleAction() {
        openTransaction("Sale");
    }

    private void handleRentalAction() {
        openTransaction("Rental");
    }

    private void handleReturnAction() {
        openTransaction("Return");
    }

    private void handleLogOutAction() {
        system1.logOut("Cashier");

        Login_Interface login = new Login_Interface();
        login.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        login.setVisible(true);

        this.setVisible(false);
        dispose();
    }
}
