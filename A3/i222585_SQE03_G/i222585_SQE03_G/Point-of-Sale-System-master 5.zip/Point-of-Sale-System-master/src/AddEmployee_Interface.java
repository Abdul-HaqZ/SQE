import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AddEmployee_Interface extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;

    // Constants for layout
    private static final int WINDOW_WIDTH = 520;
    private static final int WINDOW_HEIGHT = 200;
    private static final int BUTTON_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 20;
    private static final int NAME_FIELD_WIDTH = 150;
    private static final int PASSWORD_FIELD_WIDTH = 150;
    private static final int NAME_FIELD_X = 180;
    private static final int PASSWORD_FIELD_X = 180;
    private static final int BUTTON_X_OFFSET = 170;
    private static final int BUTTON_Y = 100;
    private static final int FIELD_Y_OFFSET = 30;
    private static final int TOOLTIP_X = 90;

    private JTextField name;
    private JPasswordField password;
    private JButton enterButton;
    private JButton exitButton;
    private JLabel passwordToolTip;
    private JLabel nameToolTip;

    private Admin_Interface admin;
    private EmployeeManagement management = new EmployeeManagement();
    private boolean registeringCashier;

    public AddEmployee_Interface(boolean regCashier, Admin_Interface admin) {
        super("SG Technologies - Register Employee");
        setLayout(null);
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setLocation(500, 280);

        registeringCashier = regCashier;
        this.admin = admin;

        initializeComponents();
        addActionListeners();
    }

    // Initialize GUI components
    private void initializeComponents() {
        name = new JTextField(15);
        name.setToolTipText("Name:");
        name.setBounds(NAME_FIELD_X, FIELD_Y_OFFSET, NAME_FIELD_WIDTH, BUTTON_HEIGHT);
        add(name);

        nameToolTip = new JLabel("Name:");
        nameToolTip.setBounds(TOOLTIP_X, FIELD_Y_OFFSET, NAME_FIELD_WIDTH, BUTTON_HEIGHT);
        add(nameToolTip);

        password = new JPasswordField(15);
        password.setToolTipText("Password");
        password.setBounds(PASSWORD_FIELD_X, FIELD_Y_OFFSET + 35, PASSWORD_FIELD_WIDTH, BUTTON_HEIGHT);
        add(password);

        passwordToolTip = new JLabel("Password:");
        passwordToolTip.setBounds(TOOLTIP_X, FIELD_Y_OFFSET + 35, PASSWORD_FIELD_WIDTH, BUTTON_HEIGHT);
        add(passwordToolTip);

        enterButton = new JButton("Enter");
        enterButton.setBounds(BUTTON_X_OFFSET, BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(enterButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(BUTTON_X_OFFSET + 100, BUTTON_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(exitButton);
    }

    // Add action listeners
    private void addActionListeners() {
        enterButton.addActionListener(this);
        exitButton.addActionListener(this);
    }
    @Override
    @SuppressWarnings("deprecation")
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == enterButton) {
            String username = name.getText();
            char[] passwordChars = password.getPassword(); // Use char[] for password handling

            management.add(username, new String(passwordChars), registeringCashier);

            closeAdminInterface();

            POSSystem sys = new POSSystem();
            admin = new Admin_Interface(sys);
            admin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            admin.setVisible(true);

            this.setVisible(false);
            dispose();
        }

        if (event.getSource() == exitButton) {
            // Cancels
            this.setVisible(false);
            dispose();
        }
    }

    // Close the admin interface when adding a new employee
    private void closeAdminInterface() {
        admin.setVisible(false);
        admin.dispose();
    }
}
