import javax.swing.JFrame;

public class Register {

    public static void main(String[] args) {
        launchLoginInterface();
    }

    // Refactored: Method to handle Login_Interface setup
    private static void launchLoginInterface() {
        Login_Interface loginInterface = new Login_Interface();
        loginInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        loginInterface.setVisible(true);
    }
}
