import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import java.util.List;

public class Admin_Interface extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 80;
    private static final int BUTTON_X_OFFSET = 4 * 5 / 5;

    private JButton addButton;
    private JButton adminButton;
    private JButton removeButton;
    private JButton updateButton;
    private JButton cashierButton;
    private JButton LogOutButton;
    private JTextArea textShow;
    private JScrollPane scroll;
    private POSSystem system1;
    private List<Employee> employeeList;
    private EmployeeManagement management = new EmployeeManagement();

    public Admin_Interface(POSSystem system2) {
        super("SG Technologies - Administrator View");
        setLayout(null);
        system1 = system2;

        // Get screen size and set window size
        Toolkit tk = Toolkit.getDefaultToolkit();
        int xSize = (int) tk.getScreenSize().getWidth();
        int ySize = (int) tk.getScreenSize().getHeight();
        setSize(xSize, ySize);

        // Initialize buttons
        addButton = createButton("Add Cashier", xSize, ySize, 1);
        adminButton = createButton("Add Admin", xSize, ySize, 2);
        removeButton = createButton("Remove Employee", xSize, ySize, 3);
        updateButton = createButton("Update Employee", xSize, ySize, 4);
        cashierButton = createButton("Cashier View", xSize, ySize, 5);
        LogOutButton = createButton("Log Out", xSize, ySize, 6);

        // Initialize text area and scroll pane
        textShow = createTextArea();
        scroll = new JScrollPane(textShow, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBounds(xSize / 16, ySize / 16, 3 * xSize / 5, 4 * ySize / 5);
        add(scroll);

        updateTextArea();

        // Add action listeners
        addButton.addActionListener(this);
        adminButton.addActionListener(this);
        removeButton.addActionListener(this);
        updateButton.addActionListener(this);
        cashierButton.addActionListener(this);
        LogOutButton.addActionListener(this);
    }

    private JButton createButton(String text, int xSize, int ySize, int position) {
        JButton button = new JButton(text);
        button.setBounds(xSize * BUTTON_X_OFFSET, ySize * position / 8, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(button);
        return button;
    }

    private JTextArea createTextArea() {
        JTextArea textArea = new JTextArea();
        textArea.setBackground(Color.white);
        textArea.setForeground(Color.black);
        textArea.setEditable(false);
        Font font = textArea.getFont();
        float size = font.getSize() + 5.0f;
        textArea.setFont(font.deriveFont(size));
        return textArea;
    }

    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == addButton) {
            openEmployeeInterface(true);
        } else if (event.getSource() == adminButton) {
            openEmployeeInterface(false);
        } else if (event.getSource() == removeButton) {
            handleRemoveEmployee();
        } else if (event.getSource() == updateButton) {
            openUpdateEmployeeInterface();
        } else if (event.getSource() == cashierButton) {
            openCashierInterface();
        } else if (event.getSource() == LogOutButton) {
            handleLogout();
        }
    }

    private void openEmployeeInterface(boolean isCashier) {
        AddEmployee_Interface empInterface = new AddEmployee_Interface(isCashier, this);
        empInterface.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        empInterface.setVisible(true);
    }

    private void handleRemoveEmployee() {
        String employeeID = JOptionPane.showInputDialog("Enter employee ID");
        if (!management.delete(employeeID)) {
            JOptionPane.showMessageDialog(null, "No employee with such ID");
        } else {
            updateTextArea();
        }
    }

    private void openUpdateEmployeeInterface() {
        UpdateEmployee_Interface update = new UpdateEmployee_Interface(this);
        update.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        update.setVisible(true);
    }

    private void openCashierInterface() {
        POSSystem sys = new POSSystem();
        Cashier_Interface cashier = new Cashier_Interface(sys);
        cashier.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cashier.setVisible(true);
        this.setVisible(false);
        dispose();
    }

    private void handleLogout() {
        system1.logOut("Admin");
        Login_Interface login = new Login_Interface();
        login.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        login.setVisible(true);
        this.setVisible(false);
        dispose();
    }

    private void updateTextArea() {
        textShow.setText(null);
        employeeList = management.getEmployeeList();
        for (Employee temp : employeeList) {
            String employeeString = formatEmployeeString(temp);
            textShow.append(employeeString);
        }
    }

    private String formatEmployeeString(Employee temp) {
        if (temp.getName().length() >= 12) {
            return temp.getUsername() + "\t" + temp.getPosition() + " \t" + temp.getName() + "\t" + temp.getPassword() + "\n";
        } else {
            return temp.getUsername() + "\t" + temp.getPosition() + " \t" + temp.getName() + "\t\t" + temp.getPassword() + "\n";
        }
    }
}
