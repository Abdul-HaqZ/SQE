import java.io.*;
import java.util.logging.Logger;

public class POR extends PointOfSale {
  private static final Logger LOGGER = Logger.getLogger(POR.class.getName());
  private static final String TEMP_FILE_PATH = "Database/newTemp.txt"; // Constant for temp file path
  private long phoneNum;

  public POR(long phoneNum) {
    this.phoneNum = phoneNum;
  }

  // Refactored deleteTempItem method using helper methods for file handling
  public void deleteTempItem(int id) {
    try {
      String temp = TEMP_FILE_PATH;
      File tempF = new File(temp);

      // Helper methods for file handling
      BufferedReader reader = readFileLines(temp);
      BufferedWriter writer = writeFileLines(tempF);

      String type = reader.readLine();
      String phone = reader.readLine();

      writer.write(type);
      writer.write(System.getProperty("line.separator"));
      writer.write(phone);
      writer.write(System.getProperty("line.separator"));

      // Write transaction items, excluding the one with the matching ID
      for (int i = 0; i < transactionItem.size(); i++) {
        if (transactionItem.get(i).getItemID() != id) {
          writer.write(transactionItem.get(i).getItemID() + " " + transactionItem.get(i).getAmount());
          writer.write(System.getProperty("line.separator"));
        }
      }

      // Closing resources
      reader.close();
      writer.close();
      deleteAndRenameTempFile(tempF);

    } catch (FileNotFoundException ex) {
      LOGGER.severe("Unable to open file 'temp'");
    } catch (IOException ex) {
      LOGGER.severe("Error reading or writing to file 'temp'");
    }
  }

//Helper method to read file lines - corrected version
private BufferedReader readFileLines(String filePath) throws IOException {
   return new BufferedReader(new FileReader(filePath));
}

  // Helper method to write file lines
  private BufferedWriter writeFileLines(File file) throws IOException {
    return new BufferedWriter(new FileWriter(file));
  }

  // Helper method to delete and rename temp file
  private void deleteAndRenameTempFile(File tempFile) {
    File file = new File(tempFile.getPath());
    file.delete();
    tempFile.renameTo(new File(TEMP_FILE_PATH));
  }

  // Refactored endPOS method using helper methods
  public double endPOS(String textFile) {
    Management man = new Management();
    man.addRental(this.phoneNum, this.transactionItem);

    detectSystem();

    if (transactionItem.size() > 0) {
      // Using helper methods for price and inventory updates
      totalPrice = calculateTotalPriceWithTax(totalPrice);
      inventory.updateInventory(textFile, transactionItem, databaseItem, true);
    }

    // Clear transaction data and delete the temp file
    deleteTempFile();
    databaseItem.clear();
    transactionItem.clear();

    return totalPrice;
  }

  // Helper method to calculate total price with tax
  private double calculateTotalPriceWithTax(double total) {
    return total * tax;
  }

  // Helper method to delete the temp file
  private void deleteTempFile() {
    File file = new File(TEMP_FILE_PATH);
    file.delete();
  }

  // Refactored retrieveTemp method using helper methods
  public void retrieveTemp(String textFile) {
    try {
      BufferedReader textReader = readFileLines(TEMP_FILE_PATH);
      String line = textReader.readLine();

      inventory.accessInventory(textFile, databaseItem);
      line = textReader.readLine();

      System.out.println("Phone number:");
      System.out.println(line);

      // Read and process transaction items
      while ((line = textReader.readLine()) != null) {
        String[] lineSort = line.split(" ");
        int itemNo = Integer.parseInt(lineSort[0]);
        int itemAmount = Integer.parseInt(lineSort[1]);
        enterItem(itemNo, itemAmount);
      }

      textReader.close();
      updateTotal();

    } catch (FileNotFoundException ex) {
      LOGGER.severe("Unable to open file 'temp'");
    } catch (IOException ex) {
      LOGGER.severe("Error reading file 'temp'");
    }
  }
}
