import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class POH extends PointOfSale {
    
    private static final Logger LOGGER = Logger.getLogger(POH.class.getName());
    private static final String TEMP_FILE = "Database/temp.txt";
    private static final String RETURN_SALE_FILE = "Database/returnSale.txt";
    private static final String NEW_TEMP_FILE = "Database/newTemp.txt";

    private List<ReturnItem> returnList = new ArrayList<>();
    private long phone;

    public POH() {
        this.phone = 0;
    }

    public POH(long phone) {
        this.phone = phone;
    }

    // Helper method to read lines from a file
    private List<String> readFileLines(String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    // Helper method to write lines to a file
    private void writeFileLines(String filePath, List<String> lines) throws IOException {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(filePath, false)))) {
            for (String line : lines) {
                writer.println(line);
            }
        }
    }

    // Deletes a temporary item by item ID
    public void deleteTempItem(int id) {
        try {
            List<String> lines = readFileLines(TEMP_FILE);
            List<String> newLines = new ArrayList<>();

            // Copy header and phone lines
            newLines.add(lines.get(0));
            newLines.add(lines.get(1));

            // Write items except the one with the specified ID
            for (int i = 2; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(" ");
                if (Integer.parseInt(parts[0]) != id) {
                    newLines.add(lines.get(i));
                }
            }

            writeFileLines(TEMP_FILE, newLines);

        } catch (FileNotFoundException ex) {
            LOGGER.log(Level.SEVERE, "Unable to open file 'temp'", ex);
        } catch (IOException ex) {
            LOGGER.log(Level.SEVERE, "Error reading or writing file 'temp'", ex);
        }
    }

    // Ends the point-of-sale process and calculates total price
    public double endPOS(String textFile) {
        double totalPrice = 0;

        if (returnSale) {
            writeReturnSaleLog();
        }

        if (!transactionItem.isEmpty() && !textFile.isEmpty()) {
            Management management = new Management();
            returnList = management.getLatestReturnDate(phone);

            totalPrice = calculateTotalPrice();

            // Update inventory and rental status
            inventory.updateInventory(textFile, transactionItem, databaseItem, false);
            management.updateRentalStatus(phone, returnList);
        }

        databaseItem.clear();
        transactionItem.clear();
        return totalPrice;
    }

    // Helper method to calculate the total price based on return items
    private double calculateTotalPrice() {
        double totalPrice = 0;
        for (Item transaction : transactionItem) {
            for (ReturnItem returned : returnList) {
                if (transaction.getItemID() == returned.getItemID()) {
                    double itemPrice = transaction.getAmount() * transaction.getPrice() * 0.1 * returned.getDays();
                    totalPrice += itemPrice;
                    LOGGER.info("Item Name: " + transaction.getItemName() + " | Days Late: " 
                                + returned.getDays() + " | To be paid: " + itemPrice);
                }
            }
        }
        LOGGER.info("Total Price: " + totalPrice);
        return totalPrice;
    }

    // Helper method to write to the return sale log
    private void writeReturnSaleLog() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RETURN_SALE_FILE, true))) {
            bw.newLine();
            for (Item item : transactionItem) {
                String log = item.getItemID() + " " + item.getItemName() + " " + item.getAmount() + " " 
                           + (item.getPrice() * item.getAmount());
                bw.write(log);
                bw.newLine();
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error writing to return sale log", e);
        }
    }

    // Retrieves temporary transaction data and populates transaction items
    public void retrieveTemp(String textFile) {
        try {
            List<String> lines = readFileLines(TEMP_FILE);
            inventory.accessInventory(textFile, databaseItem);

            LOGGER.info("Phone number: " + lines.get(1));
            for (int i = 2; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(" ");
                int itemID = Integer.parseInt(parts[0]);
                int itemAmount = Integer.parseInt(parts[1]);
                enterItem(itemID, itemAmount);
            }

            updateTotal();

        } catch (FileNotFoundException ex) {
            LOGGER.log(Level.SEVERE, "Unable to open file 'temp'", ex);
        } catch (IOException ex) {
            LOGGER.log(Level.SEVERE, "Error reading file 'temp'", ex);
        }
    }
}
