import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;
import java.io.FileNotFoundException;

public class POSSystem {
  public boolean unixOS = true;
  public static String employeeDatabase = "Database/employeeDatabase.txt";
  public static String rentalDatabaseFile = "Database/rentalDatabase.txt";
  public static String itemDatabaseFile = "Database/itemDatabase.txt";
  public List<Employee> employees = new ArrayList<Employee>();
  DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
  Calendar cal = null;
  private int index = -1;
  String username = "";
  String password = "";
  String name = "";

  private static final String EMPLOYEE_LOG_FILE = "Database/employeeLogfile.txt";
  private static final String TEMP_FILE = "Database/temp.txt";

  // Extracted the file reading logic to its own method
  private void readEmployeeFile() {
    String line = null;
    String[] lineSort;

    try {
      FileReader fileR = new FileReader(employeeDatabase);
      BufferedReader textReader = new BufferedReader(fileR);

      while ((line = textReader.readLine()) != null) {
        lineSort = line.split(" ");  // separates words
        String name = lineSort[2] + " " + lineSort[3];
        employees.add(new Employee(lineSort[0], name, lineSort[1], lineSort[4]));
      }
      textReader.close();
    } catch (FileNotFoundException ex) {
      System.out.println("Unable to open file '" + employeeDatabase + "'");
    } catch (IOException ex) {
      System.out.println("Error reading file '" + employeeDatabase + "'");
    }
  }

  // Refactored log writing to its own method
  private void logToFile(String message) {
    try {
      FileWriter fw = new FileWriter(EMPLOYEE_LOG_FILE, true);
      BufferedWriter bw = new BufferedWriter(fw);
      bw.write(message);
      bw.write(System.getProperty("line.separator"));
      bw.close();
    } catch (IOException e) {
      System.out.println("Unable to open log file");
      e.printStackTrace();
    }
  }

  private void logInToFile(String username, String name, String position, Calendar cal) {
    String log = name + " (" + username + " " + position + ") logs into POS System. Time: " + dateFormat.format(cal.getTime());
    logToFile(log);
  }

  private void logOutToFile(String username, String name, String position, Calendar cal) {
    String log = name + " (" + username + " " + position + ") logs out of POS System. Time: " + dateFormat.format(cal.getTime());
    logToFile(log);
  }

  public boolean checkTemp() {
    File f = new File(TEMP_FILE);
    return f.exists() && !f.isDirectory();
  }

  // Refactored to simplify and reuse the logic for reading temp file
  public String continueFromTemp(long phone) {
    String result = "";
    try {
      FileReader fileR = new FileReader(TEMP_FILE);
      BufferedReader textReader = new BufferedReader(fileR);

      if (new File(TEMP_FILE).length() == 0) {
        System.out.println("The log file is not valid");
        new File(TEMP_FILE).delete();
        return result;
      }

      String type = textReader.readLine();
      if ("Sale".equals(type)) {
        POS sale = new POS();
        sale.retrieveTemp(itemDatabaseFile);
        result = "Sale";
      } else if ("Rental".equals(type)) {
        POR rental = new POR(phone);
        rental.retrieveTemp(rentalDatabaseFile);
        result = "Rental";
      } else if ("Return".equals(type)) {
        POH returns = new POH(phone);
        returns.retrieveTemp(rentalDatabaseFile);
        result = "Return";
      }

      textReader.close();
    } catch (FileNotFoundException ex) {
      System.out.println("Unable to open file 'temp'");
    } catch (IOException ex) {
      System.out.println("Error reading file 'temp'");
    }

    return result;
  }

  public void logOut(String pos) {
    cal = Calendar.getInstance();
    logOutToFile(username, name, pos, cal);
  }

  public int logIn(String userAuth, String passAuth) {
    readEmployeeFile();
    username = userAuth;
    boolean found = false;

    for (int i = 0; i < employees.size(); i++) {
      if (username.equals(employees.get(i).getUsername())) {
        found = true;
        index = i;
        break;
      }
    }

    if (found) {
      password = passAuth;
      if (!password.equals(employees.get(index).getPassword())) {
        return 0; // incorrect password
      } else {
        // employee logIn file update
        cal = Calendar.getInstance();
        name = employees.get(index).getName();
        logInToFile(employees.get(index).getUsername(), name, employees.get(index).getPosition(), cal);

        String position = employees.get(index).getPosition();
        if ("Cashier".equals(position)) {
          return 1;  // cashier status
        } else if ("Admin".equals(position)) {
          return 2;  // admin status
        }
      }
    }

    return 0;  // username not found
  }
}
