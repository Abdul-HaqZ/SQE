/**
 * Represents an item in inventory, including details such as item ID, name, price, and amount.
 */
public class Item {
    
    // Attributes
    private int itemID;          // Unique identifier for the item
    private String itemName;     // Name of the item
    private float price;         // Price of the item
    private int amount;          // Quantity of the item available in inventory
    
    /**
     * Constructor to initialize an item with specified attributes.
     * 
     * @param itemID   The unique identifier for the item.
     * @param itemName The name of the item.
     * @param price    The price of the item.
     * @param amount   The quantity of the item available in inventory.
     */
    public Item(int itemID, String itemName, float price, int amount) {
        this.itemID = itemID;
        this.itemName = itemName;
        this.price = price;
        this.amount = amount;
    }

    // Getter methods with explicit public access for usage across packages
    
    /**
     * Gets the name of the item.
     * @return The item name.
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * Gets the unique identifier of the item.
     * @return The item ID.
     */
    public int getItemID() {
        return itemID;
    }

    /**
     * Gets the price of the item.
     * @return The price.
     */
    public float getPrice() {
        return price;
    }

    /**
     * Gets the current quantity of the item in inventory.
     * @return The amount of the item.
     */
    public int getAmount() {
        return amount;
    }

    /**
     * Updates the quantity of the item in inventory.
     * Ensures that the amount is non-negative, maintaining data integrity.
     * 
     * @param amount The new quantity to set.
     * @throws IllegalArgumentException if amount is negative.
     */
    public void updateAmount(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount cannot be negative.");
        }
        this.amount = amount;
    }
}
