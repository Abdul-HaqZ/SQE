import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JOptionPane;

public class Login_Interface extends JFrame implements ActionListener{

    private static final long serialVersionUID = 1L;

    // Constants for layout positioning and dimensions
    private static final int WINDOW_WIDTH = 520;
    private static final int WINDOW_HEIGHT = 200;
    private static final int BUTTON_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 20;
    private static final int TEXTFIELD_WIDTH = 150;
    private static final int TEXTFIELD_HEIGHT = 20;

    // GUI widgets
    private JTextField username;
    private JPasswordField password;
    private JButton loginButton;
    private JButton exitButton;
    private JLabel userToolTip;
    private JLabel passToolTip;

    // Authentication variables
    private String userAuth = "";
    private String passwordAuth = "";

    private POSSystem System = new POSSystem();

    // Constructor
    public Login_Interface() {
        super("SG Technologies - Login Authentication");

        setLayout(null);
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setLocation(500, 280);

        // Set up the UI components
        userToolTip = new JLabel("Username:");
        userToolTip.setBounds(90, 30, 150, 20);
        add(userToolTip);

        passToolTip = new JLabel("Password:");
        passToolTip.setBounds(90, 65, 150, 20);
        add(passToolTip);

        username = new JTextField(15);
        username.setToolTipText("Username:");
        username.setBounds(180, 30, TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT);
        add(username);

        password = new JPasswordField(15);
        password.setToolTipText("Password");
        password.setBounds(180, 65, TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT);
        add(password);

        loginButton = new JButton("Login");
        loginButton.setBounds(170, 100, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(loginButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(270, 100, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(exitButton);

        loginButton.addActionListener(this);
        exitButton.addActionListener(this);
    }

    @SuppressWarnings("deprecation")
    public void actionPerformed(ActionEvent event) {
        // Handle button actions
        if (event.getSource() == loginButton) {
            handleLoginAction();
        } else if (event.getSource() == exitButton) {
            handleExitAction();
        }
    }

    // Handle login action
    @SuppressWarnings("deprecation")
	private void handleLoginAction() {
        userAuth = username.getText();
        passwordAuth = password.getText();

        if (System.logIn(userAuth, passwordAuth) == 1) {
            navigateToCashier();
        } else if (System.logIn(userAuth, passwordAuth) == 2) {
            navigateToAdmin();
        } else {
            showErrorMessage();
        }
    }

    // Navigate to Cashier interface
    private void navigateToCashier() {
        Cashier_Interface cashier = new Cashier_Interface(System);
        cashier.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cashier.setVisible(true);
        disposeInterface();
    }

    // Navigate to Admin interface
    private void navigateToAdmin() {
        Admin_Interface admin = new Admin_Interface(System);
        admin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        admin.setVisible(true);
        disposeInterface();
    }

    // Show error message for wrong authentication
    private void showErrorMessage() {
        JOptionPane.showMessageDialog(null, "Wrong Authentication Credentials");
        username.setText("");
        password.setText("");
        username.requestFocus();
    }

    // Dispose of the current interface
    private void disposeInterface() {
        this.setVisible(false);
        dispose();
    }

    // Handle exit action
    private void handleExitAction() {
        disposeInterface();
    }
}
