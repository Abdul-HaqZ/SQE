import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class UpdateEmployee_Interface extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    // Constants for window size and button positions
    private static final int WINDOW_WIDTH = 520;
    private static final int WINDOW_HEIGHT = 300;
    private static final int BUTTON_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 20;
    private static final int TEXT_FIELD_WIDTH = 150;
    private static final int TEXT_FIELD_HEIGHT = 20;

    // GUI widgets for this interface
    private JTextField username;
    private JPasswordField password;
    private JButton enterButton;
    private JButton exitButton;
    private JLabel userToolTip;
    private JLabel passToolTip;
    private JTextField position;
    private JLabel positionToolTip;
    private JTextField name;
    private JLabel nameToolTip;

    private Admin_Interface admin;

    public UpdateEmployee_Interface(Admin_Interface admin) {
        super("SG Technologies - Update Employee Info");
        setLayout(null);
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setLocation(500, 280);

        this.admin = admin;

        initializeUI();
    }

    private void initializeUI() {
        userToolTip = new JLabel("Username:");
        userToolTip.setBounds(90, 30, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(userToolTip);

        nameToolTip = new JLabel("Name:");
        nameToolTip.setBounds(90, 65, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(nameToolTip);

        passToolTip = new JLabel("Password:");
        passToolTip.setBounds(90, 110, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(passToolTip);

        positionToolTip = new JLabel("Position:");
        positionToolTip.setBounds(90, 145, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(positionToolTip);

        position = new JTextField(15);
        position.setBounds(180, 145, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(position);

        username = new JTextField(15);
        username.setToolTipText("Username:");
        username.setBounds(180, 30, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(username);

        name = new JTextField(15);
        name.setBounds(180, 65, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(name);

        password = new JPasswordField(15);
        password.setToolTipText("Password");
        password.setBounds(180, 110, TEXT_FIELD_WIDTH, TEXT_FIELD_HEIGHT);
        add(password);

        enterButton = new JButton("Enter");
        enterButton.setBounds(170, 200, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(enterButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(270, 200, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(exitButton);

        enterButton.addActionListener(this);
        exitButton.addActionListener(this);
    }

    @SuppressWarnings("deprecation")
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == enterButton) {
            handleEnterButtonClick();
        } else if (event.getSource() == exitButton) {
            handleExitButtonClick();
        }
    }

    private void handleEnterButtonClick() {
        EmployeeManagement management = new EmployeeManagement();
        int result = management.update(username.getText(), password.getText(), position.getText(), name.getText());

        if (result == -1) {
            showErrorMessage("Employee with such username doesn't exist");
        } else if (result == -2) {
            showErrorMessage("Invalid employee position");
        } else {
            navigateToAdminInterface();
        }
    }

    private void handleExitButtonClick() {
        disposeInterface(this);
    }

    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    private void navigateToAdminInterface() {
        admin.setVisible(false);
        admin.dispose();

        POSSystem sys = new POSSystem();
        admin = new Admin_Interface(sys);
        admin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        admin.setVisible(true);

        disposeInterface(this);
    }

    private void disposeInterface(JFrame frame) {
        frame.setVisible(false);
        frame.dispose();
    }
}
