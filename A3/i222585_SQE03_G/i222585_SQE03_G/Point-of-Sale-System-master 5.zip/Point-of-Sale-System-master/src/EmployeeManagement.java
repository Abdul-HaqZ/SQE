import java.util.*;
import java.io.*;
import java.util.logging.Logger;

public class EmployeeManagement {
    private static final String TEMP_DATABASE_FILE = "Database/newEmployeeDatabase.txt";
    private static final String EMPLOYEE_DATABASE = "Database/employeeDatabase.txt";
    private static final String ROLE_ADMIN = "Admin";
    private static final String ROLE_CASHIER = "Cashier";

    private static final Logger LOGGER = Logger.getLogger(EmployeeManagement.class.getName());

    public List<Employee> employees = new ArrayList<>();

    public EmployeeManagement() {}

    public List<Employee> getEmployeeList() {
        readFile();
        return employees;
    }

    public void add(String name, String password, boolean isEmployee) {
        readFile();
        int username = employees.isEmpty() ? 1 : Integer.parseInt(employees.get(employees.size() - 1).getUsername()) + 1;
        String position = isEmployee ? ROLE_CASHIER : ROLE_ADMIN;
        String toWrite = username + " " + position + " " + name + " " + password;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(EMPLOYEE_DATABASE, true))) {
            bw.write(toWrite);
            bw.newLine();
        } catch (IOException e) {
            LOGGER.severe("Error writing to employee database: " + e.getMessage());
        }
    }

    public boolean delete(String username) {
        readFile();
        boolean found = false;
        int index = -1;

        for (int i = 0; i < employees.size(); i++) {
            if (username.equals(employees.get(i).getUsername())) {
                found = true;
                index = i;
                break;
            }
        }
        if (!found) return false;

        employees.remove(index);

        try {
            writeEmployeeDataToFile(TEMP_DATABASE_FILE);
            File originalFile = new File(EMPLOYEE_DATABASE);
            originalFile.delete();
            new File(TEMP_DATABASE_FILE).renameTo(originalFile);
            return true;
        } catch (IOException e) {
            LOGGER.severe("Error updating database after deletion: " + e.getMessage());
            return false;
        }
    }

    public int update(String username, String password, String position, String name) {
        readFile();
        int userFound = -1;
        int index = -1;

        for (int i = 0; i < employees.size(); i++) {
            if (username.equals(employees.get(i).getUsername())) {
                userFound = 0;
                index = i;
                break;
            }
        }

        if (userFound == 0) {
            if (!position.isEmpty() && !(position.equals(ROLE_ADMIN) || position.equals(ROLE_CASHIER))) {
                return -2;
            }

            // Update information
            if (!password.isEmpty()) employees.get(index).setPassword(password);
            if (!position.isEmpty()) employees.get(index).setPosition(position);
            if (!name.isEmpty()) employees.get(index).setName(name);

            try {
                writeEmployeeDataToFile(TEMP_DATABASE_FILE);
                File originalFile = new File(EMPLOYEE_DATABASE);
                originalFile.delete();
                new File(TEMP_DATABASE_FILE).renameTo(originalFile);
            } catch (IOException e) {
                LOGGER.severe("Error updating employee record: " + e.getMessage());
            }
        }

        return userFound;
    }

    private void readFile() {
        employees.clear();
        try {
            readEmployeeDataFromFile(EMPLOYEE_DATABASE);
        } catch (IOException e) {
            LOGGER.severe("Error reading employee database: " + e.getMessage());
        }
    }

    private void writeEmployeeDataToFile(String filePath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Employee emp : employees) {
                writer.write(emp.getUsername() + " " + emp.getPosition() + " " + emp.getName() + " " + emp.getPassword());
                writer.newLine();
            }
        }
    }

    private void readEmployeeDataFromFile(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(" ");
                String name = data[2] + " " + data[3];
                employees.add(new Employee(data[0], name, data[1], data[4]));
            }
        }
    }
}
