import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class EnterItem_Interface extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;

    // GUI constants for dimensions
    private static final int BUTTON_WIDTH = 80;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_VERTICAL_SPACING = 100;
    private static final int TEXTFIELD_WIDTH = 150;
    private static final int TEXTFIELD_HEIGHT = 20;

    // GUI widgets for this interface
    private JTextField itemID;
    private JTextField amount;
    private JButton enterButton;
    private JButton exitButton;
    private JLabel amountToolTip;
    private JLabel itemToolTip;
    private JTextArea transDialog;

    private String ID = "";
    private String quantity = "";
    private PointOfSale transaction;
    private boolean checkFlag;
    private String operation;
    private int choice;

    public EnterItem_Interface(PointOfSale transac, boolean addFlag, JTextArea transactionDialog, String operation, int choice) {
        super("SG Technologies - Enter Item");
        setLayout(null);
        setSize(520, 200);
        setLocation(500, 280);

        this.operation = operation;
        this.choice = choice;
        this.transaction = transac;
        this.checkFlag = addFlag;
        this.transDialog = transactionDialog;

        setupUI(addFlag);

        // Add action listeners
        enterButton.addActionListener(this);
        exitButton.addActionListener(this);
    }

    private void setupUI(boolean addFlag) {
        enterButton = new JButton("Enter");
        enterButton.setBounds(170, BUTTON_VERTICAL_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(enterButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(270, BUTTON_VERTICAL_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT);
        add(exitButton);

        itemID = new JTextField(15);
        itemID.setToolTipText("itemID:");
        itemID.setBounds(180, 30, TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT);
        add(itemID);

        itemToolTip = new JLabel("Item ID:");
        itemToolTip.setBounds(90, 30, TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT);
        add(itemToolTip);

        if (addFlag) {
            amount = new JTextField(15);
            amount.setToolTipText("amount");
            amount.setBounds(180, 65, TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT);
            add(amount);

            amountToolTip = new JLabel("Amount:");
            amountToolTip.setBounds(90, 65, TEXTFIELD_WIDTH, TEXTFIELD_HEIGHT);
            add(amountToolTip);
        }
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == enterButton) {
            handleEnterButtonAction();
        } else if (event.getSource() == exitButton) {
            disposeInterface();
        }
    }

    private void handleEnterButtonAction() {
        ID = itemID.getText();
        if (checkFlag) {
            handleAddItem();
        } else {
            handleRemoveItem();
        }
        disposeInterface();
    }

    private void handleAddItem() {
        quantity = amount.getText();
        if (!transaction.enterItem(getItemID(), getAmount())) {
            JOptionPane.showMessageDialog(null, "Item not found on inventory");
        } else {
            transaction.updateTotal();
            updateTextArea();
        }
    }

    private void handleRemoveItem() {
        if (!transaction.removeItems(getItemID())) {
            JOptionPane.showMessageDialog(null, "No such item on cart");
        } else {
            updateTextArea();
        }
    }

    private void disposeInterface() {
        this.setVisible(false);
        dispose();
    }

    private void updateTextArea() {
        transDialog.setText(null);
        List<Item> transactionItem = transaction.getCart();
        for (Item temp : transactionItem) {
            String itemString = String.format("%s\t%s\t x%d\t$%.2f%n",
                    temp.getItemID(), temp.getItemName(), temp.getAmount(), temp.getAmount() * temp.getPrice());
            transDialog.append(itemString);
        }

        String totalString = operation.equals("Return") && choice == 0
                ? String.format("\nTotal Price When Items Were Rented: $%.2f\n", transaction.getTotal())
                : String.format("\nTotal: $%.2f\n", transaction.getTotal());
        transDialog.append(totalString);
    }

    public int getItemID() {
        return Integer.parseInt(ID);
    }

    public int getAmount() {
        return Integer.parseInt(quantity);
    }
}
