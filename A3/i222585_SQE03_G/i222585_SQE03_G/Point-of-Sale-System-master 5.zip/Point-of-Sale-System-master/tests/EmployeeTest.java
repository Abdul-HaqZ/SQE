import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Test class for Employee.
 */
public class EmployeeTest {
   
    public EmployeeTest() {
    }
   
    @BeforeClass
    public static void setUpClass() {
    }
   
    @AfterClass
    public static void tearDownClass() {
    }
   
    @Before
    public void setUp() {
    }
   
    @After
    public void tearDown() {
    }

    /**
     * Test of getUsername method, of class Employee.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String expResult = "10001";
        String result = instance.getUsername();
        assertEquals(expResult, result);
    }

    /**
     * Test of getName method, of class Employee.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String expResult = "Alpha Release";
        String result = instance.getName();
        assertEquals(expResult, result);
    }

    /**
     * Test of getPosition method, of class Employee.
     */
    @Test
    public void testGetPosition() {
        System.out.println("getPosition");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String expResult = "Admin";
        String result = instance.getPosition();
        assertEquals(expResult, result);
    }

    /**
     * Test of getPassword method, of class Employee.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String expResult = "123345";
        String result = instance.getPassword();
        assertEquals(expResult, result);
    }

    /**
     * Test of setName method, of class Employee.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String newName = "Beta Release";
        instance.setName(newName);
        assertEquals(newName, instance.getName());
    }

    /**
     * Test of setPosition method, of class Employee.
     */
    @Test
    public void testSetPosition() {
        System.out.println("setPosition");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String newPosition = "User";
        instance.setPosition(newPosition);
        assertEquals(newPosition, instance.getPosition());
    }

    /**
     * Test of setPassword method, of class Employee.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        Employee instance = new Employee("10001", "Alpha Release", "Admin", "123345");
        String newPassword = "54321";
        instance.setPassword(newPassword);
        assertEquals(newPassword, instance.getPassword());
    }
}

