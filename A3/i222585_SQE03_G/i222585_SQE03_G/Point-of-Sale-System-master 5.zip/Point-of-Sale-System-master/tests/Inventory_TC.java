import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.*;
import java.util.*;

public class Inventory_TC {

    private Inventory inventory;
    private List<Item> databaseItems;
    private List<Item> transactionItems;
    private String testDatabaseFile;

    @Before
    public void setUp() {
        inventory = Inventory.getInstance(); // Singleton instance
        databaseItems = new ArrayList<>(Arrays.asList(
            new Item(1, "Item1", 10.0f, 20),
            new Item(2, "Item2", 15.0f, 30)
        ));
        transactionItems = new ArrayList<>(Arrays.asList(
            new Item(1, "Item1", 10.0f, 5) // Test transaction item
        ));
        testDatabaseFile = "testInventoryDatabase.txt";
        writeTestFile(testDatabaseFile, databaseItems); // Initialize test file
    }

    @After
    public void tearDown() {
        File file = new File(testDatabaseFile);
        if (file.exists()) {
            file.delete(); // Clean up test file
        }
    }

    @Test
    public void testSingletonInstance() {
        Inventory anotherInstance = Inventory.getInstance();
        assertSame(inventory, anotherInstance); // Ensure the same instance is returned
    }

    @Test
    public void testAccessInventory_Success() {
        boolean result = inventory.accessInventory(testDatabaseFile, new ArrayList<>());
        assertTrue(result); // Ensure inventory is accessed successfully
    }

    @Test
    public void testAccessInventory_FileNotFound() {
        boolean result = inventory.accessInventory("nonExistingFile.txt", new ArrayList<>());
        assertFalse(result); // Ensure inventory access fails due to missing file
    }

    @Test
    public void testAccessInventory_IOException() {
        // Simulate IOException by making the file read-only
        File file = new File(testDatabaseFile);
        file.setReadOnly();

        boolean result = inventory.accessInventory(testDatabaseFile, new ArrayList<>());
        assertFalse(result); // Ensure inventory access fails due to read-only file

        file.setWritable(true); // Restore write permission for other tests
    }

    @Test
    public void testUpdateInventory_TakeFromInventory() {
        inventory.updateInventory(testDatabaseFile, transactionItems, databaseItems, true);

        assertEquals(15, databaseItems.get(0).getAmount()); // Item1 amount should decrease
        assertEquals(30, databaseItems.get(1).getAmount()); // Item2 amount remains the same
    }

    @Test
    public void testUpdateInventory_AddToInventory() {
        inventory.updateInventory(testDatabaseFile, transactionItems, databaseItems, false);

        assertEquals(25, databaseItems.get(0).getAmount()); // Item1 amount should increase
        assertEquals(30, databaseItems.get(1).getAmount()); // Item2 amount remains the same
    }

    @Test
    public void testUpdateInventory_NoMatchingItem() {
        List<Item> nonMatchingTransaction = new ArrayList<>(Arrays.asList(
            new Item(999, "NonExistingItem", 50.0f, 10) // This item doesn't exist in the database
        ));

        inventory.updateInventory(testDatabaseFile, nonMatchingTransaction, databaseItems, true);

        assertEquals(20, databaseItems.get(0).getAmount()); // Item1 amount remains unchanged
        assertEquals(30, databaseItems.get(1).getAmount()); // Item2 amount remains unchanged
    }

    @Test
    public void testUpdateInventory_FileIOException() {
        // Simulate IOException by making the file read-only
        File file = new File(testDatabaseFile);
        file.setReadOnly();

        inventory.updateInventory(testDatabaseFile, transactionItems, databaseItems, true);

        // The file is read-only, so the update should fail, but no exception should be thrown
        assertEquals(20, databaseItems.get(0).getAmount()); // Amount should remain unchanged

        file.setWritable(true); // Restore write permission for other tests
    }

    private void writeTestFile(String filename, List<Item> items) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Item item : items) {
                writer.write(item.getItemID() + " " + item.getItemName() + " " + item.getPrice() + " " + item.getAmount());
                writer.newLine();
            }
        } catch (IOException e) {
            fail("Failed to write test database file");
        }
    }
}
