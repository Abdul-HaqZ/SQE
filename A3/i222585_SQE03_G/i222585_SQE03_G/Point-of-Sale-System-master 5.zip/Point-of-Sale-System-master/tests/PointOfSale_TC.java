
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.Files;

public class PointOfSale_TC {
    private PointOfSale pos;	
    private Inventory inventory;
    private File tempDatabaseFile;
    private File tempCouponFile;
 
    // Concrete subclass for abstract PointOfSale methods
    class TestPOS extends PointOfSale {
        @Override
        public double endPOS(String textFile) {
            return totalPrice;
        }

        @Override
        public void deleteTempItem(int id) {
            // Dummy implementation for abstract method
        }

        @Override
        public void retrieveTemp(String textFile) {
            // Dummy implementation for abstract method
        }
    }

    @Before
    public void setUp() throws IOException {
        // Create concrete implementation for PointOfSale
        pos = new TestPOS();
        inventory = Inventory.getInstance();

        // Create temporary files to act as database and coupon files
        tempDatabaseFile = Files.createTempFile("testDatabase", ".txt").toFile();
        tempCouponFile = Files.createTempFile("testCoupon", ".txt").toFile();

        // Populate temp database file with sample items
        try (PrintWriter writer = new PrintWriter(new FileWriter(tempDatabaseFile))) {
            writer.println("1 Apple 1.0 10");
            writer.println("2 Banana 0.5 20");
        }

        // Populate temp coupon file with sample coupons
        try (PrintWriter writer = new PrintWriter(new FileWriter(tempCouponFile))) {
            writer.println("VALIDCOUPON");
        }

        // Use temp files in the PointOfSale system
        pos.couponNumber = tempCouponFile.getAbsolutePath();
    }

    @Test
    // Statement coverage: Testing the inventory access with a valid temp file.
    public void testStartNew_success() {
        assertTrue(pos.startNew(tempDatabaseFile.getAbsolutePath()));
    }

    @Test
    // Condition and decision coverage: Testing adding an item that exists in the temp database.
    public void testEnterItem_found() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        assertTrue(pos.enterItem(1, 2)); // Apple
        assertEquals(1, pos.getCartSize()); // Statement coverage: Check cart size after adding an item
        assertEquals(2, pos.getCart().get(0).getAmount()); // Statement coverage: Check amount of added item
    }

    @Test
    // Condition coverage: Testing adding an item that doesn't exist in the database.
    public void testEnterItem_notFound() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        assertFalse(pos.enterItem(999, 2)); // Non-existent item
    }

    @Test
    // Statement coverage: Testing the total price calculation after adding an item.
    public void testUpdateTotal() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        pos.enterItem(1, 2); // Apple
        assertEquals(2.0, pos.updateTotal(), 0.01);
    }

    @Test
    // Condition and decision coverage: Testing application of a valid coupon.
    public void testCoupon_validCoupon() {
        pos.totalPrice = 100.0;
        assertTrue(pos.coupon("VALIDCOUPON"));
        assertEquals(90.0, pos.totalPrice, 0.01); // 10% discount applied
    }

    @Test
    // Condition and decision coverage: Testing application of an invalid coupon.
    public void testCoupon_invalidCoupon() {
        pos.totalPrice = 100.0;
        assertFalse(pos.coupon("INVALIDCOUPON"));
        assertEquals(100.0, pos.totalPrice, 0.01); // No discount applied
    }

    @Test
    // Condition and decision coverage: Testing removal of an existing item.
    public void testRemoveItems_itemFound() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        pos.enterItem(1, 2); // Add Apple
        pos.updateTotal(); // Update total to include item price
        assertTrue(pos.removeItems(1)); // Remove Apple
        assertEquals(0, pos.getCartSize()); // Statement coverage: Cart size should be 0 after removal
        assertEquals(0, pos.getTotal(), 0.01); // Statement coverage: Total price should be 0 after removal
    }

    @Test
    // Condition coverage: Testing removal of a non-existing item.
    public void testRemoveItems_itemNotFound() {
        assertFalse(pos.removeItems(999)); // Try removing non-existent item
    }

    @Test
    // Condition coverage: Testing valid credit card number.
    public void testCreditCard_valid() {
        assertTrue(pos.creditCard("1234567812345678"));
    }

    @Test
    // Condition coverage: Testing invalid credit card number due to length.
    public void testCreditCard_invalidLength() {
        assertFalse(pos.creditCard("12345678")); // Invalid length
    }

    @Test
    // Condition coverage: Testing invalid credit card number due to non-numeric characters.
    public void testCreditCard_invalidCharacters() {
        assertFalse(pos.creditCard("12345678abcd5678")); // Invalid characters
    }

    @Test
    // Statement coverage: Testing the default behavior of system detection.
    public void testDetectSystem() {
        pos.detectSystem();
        assertTrue(pos.unixOS); // Default behavior assumes Unix-like OS
    }

    @Test
    // Statement and condition coverage: Testing creation of a temporary file.
    public void testCreateTemp() throws IOException {
        File tempFile = Files.createTempFile("testTemp", ".txt").toFile();
        pos.tempFile = tempFile.getAbsolutePath();
        pos.createTemp(1, 5); // Create a temp file entry

        try (BufferedReader reader = new BufferedReader(new FileReader(tempFile))) {
            String line = reader.readLine();
            assertEquals("1 5", line); // Check that the correct entry was written
        }

        tempFile.delete(); // Cleanup the temp file
    }

    @Test
    // Statement coverage: Testing retrieval of the last added item.
    public void testLastAddedItem() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        pos.enterItem(1, 3); // Add Apple
        Item lastItem = pos.lastAddedItem();
        assertEquals(1, lastItem.getItemID());
        assertEquals(3, lastItem.getAmount());
    }

    @Test
    // Statement coverage: Testing retrieval of the total price.
    public void testGetTotal() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        pos.enterItem(1, 2); // Add Apple
        pos.updateTotal();
        assertEquals(2.0, pos.getTotal(), 0.01); // Total price should reflect added items
    }

    @Test
    // Statement coverage: Testing retrieval of the cart size.
    public void testGetCartSize() {
        pos.startNew(tempDatabaseFile.getAbsolutePath());
        pos.enterItem(1, 2); // Add Apple
        assertEquals(1, pos.getCartSize()); // Ensure cart size is updated
    }

    @Test
    // Condition coverage: Testing handling of a missing database file.
    public void testStartNew_fileNotFound() {
        assertFalse(pos.startNew("nonExistentFile.txt"));
    }
}