import static org.junit.Assert.*;
import org.junit.Test;

public class Returnitem_TC {

    @Test
    public void testReturnItemConstructor() {
        int expectedItemID = 1;
        int expectedDaysSinceReturn = 5;

        ReturnItem returnItem = new ReturnItem(expectedItemID, expectedDaysSinceReturn);

        assertEquals("Item ID should be set correctly.", expectedItemID, returnItem.getItemID());
        assertEquals("Days since return should be set correctly.", expectedDaysSinceReturn, returnItem.getDays());
    }

    @Test
    public void testGetItemID() {
        ReturnItem returnItem = new ReturnItem(2, 3);
        assertEquals("Item ID should be 2.", 2, returnItem.getItemID());
    }

    @Test
    public void testGetDaysSinceReturn() {
        ReturnItem returnItem = new ReturnItem(3, 10);
        assertEquals("Days since return should be 10.", 10, returnItem.getDays());
    }
}
