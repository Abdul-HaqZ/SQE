import org.junit.Before;
import org.junit.Test;
import org.junit.After;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.*;

public class POR_TC {

    private POR por;
    private String tempFilePath = "Database/temp.txt";
    private String newTempFilePath = "Database/newTemp.txt";
    private String inventoryFilePath = "Database/inventory.txt";

    @Before
    public void setUp() {
        por = new POR(1234567890L);
        por.tempFile = tempFilePath;
    }

    @Test
    // Statement and decision coverage: Testing deletion of an item with existing ID.
    public void testDeleteTempItem() throws IOException {
        createTempFile();
        por.transactionItem.add(new Item(1, "Item 1", 2, 10));
        por.transactionItem.add(new Item(2, "Item 2", 3, 15));
        por.transactionItem.add(new Item(3, "Item 3", 4, 20));

        // Delete item with ID 2
        por.deleteTempItem(2);

        // Verify the content of the new temp file
        try (BufferedReader br = new BufferedReader(new FileReader(tempFilePath))) {
            assertEquals("TypeOfData", br.readLine());
            assertEquals("1234567890", br.readLine());
        }
    }

    @Test
    // Statement and branch coverage: Testing deletion of an item with non-existent ID.
    public void testDeleteTempItemNonExistentId() throws IOException {
        createTempFile();
        por.transactionItem.add(new Item(1, "Item 1", 2, 10));
        por.transactionItem.add(new Item(2, "Item 2", 3, 15));

        // Attempt to delete a non-existent item (ID = 5)
        por.deleteTempItem(5);

        // Verify file content remains unchanged
        try (BufferedReader br = new BufferedReader(new FileReader(tempFilePath))) {
            assertEquals("TypeOfData", br.readLine());
            assertEquals("1234567890", br.readLine());
        }
    }

    @Test
    // Statement and condition coverage: Testing end of POS with return items.
    public void testEndPOSWithReturnItems() throws IOException {
        createInventoryFile();
        por.returnSale = true;
        por.transactionItem.add(new Item(1, "Item 1", 2, 10));
        por.transactionItem.add(new Item(2, "Item 2", 1, 15));

        double totalPrice = por.endPOS(inventoryFilePath);

        assertEquals(0.0, totalPrice, 0.001); // For return sale, total should be 0
        assertTrue(Files.exists(Paths.get(inventoryFilePath)));
        assertFalse(Files.exists(Paths.get(tempFilePath)));
    }

    @Test
    // Statement coverage: Testing end of POS without return items.
    public void testEndPOSWithoutReturnItems() throws IOException {
        createInventoryFile();
        por.returnSale = false;
        por.transactionItem.add(new Item(1, "Item 1", 2, 10));
        por.transactionItem.add(new Item(2, "Item 2", 1, 15));

        double totalPrice = por.endPOS(inventoryFilePath);
    }

    @Test
    // Statement coverage: Testing retrieval of temp data from a valid file.
    public void testRetrieveTemp() throws IOException {
        createTempFile();
        por.retrieveTemp(inventoryFilePath);
    }

    @Test(expected = FileNotFoundException.class)
    // Condition coverage: Testing handling of FileNotFoundException in retrieveTemp.
    public void testRetrieveTempFileNotFound() throws IOException {
        por.tempFile = "nonexistent.txt";
        por.retrieveTemp(inventoryFilePath);
    }

    @Test
    // Statement coverage: Testing updateTotal method.
    public void testUpdateTotal() {
        por.transactionItem.add(new Item(1, "Item 1", 2, 10));
        por.transactionItem.add(new Item(2, "Item 2", 1, 15));
        por.updateTotal();
    }

    private void createTempFile() throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(tempFilePath))) {
            bw.write("TypeOfData");
            bw.newLine();
            bw.write("1234567890");
            bw.newLine();
            bw.write("1 2");
            bw.newLine();
            bw.write("2 3");
            bw.newLine();
        }
    }

    private void createInventoryFile() throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(inventoryFilePath))) {
            bw.write("1,Item 1,10,100");
            bw.newLine();
            bw.write("2,Item 2,15,50");
            bw.newLine();
        }
    }

    @After
    public void tearDown() throws IOException {
        // Clean up: delete the temp files after each test
        Files.deleteIfExists(Paths.get(tempFilePath));
        Files.deleteIfExists(Paths.get(newTempFilePath));
        Files.deleteIfExists(Paths.get(inventoryFilePath));
    }
}