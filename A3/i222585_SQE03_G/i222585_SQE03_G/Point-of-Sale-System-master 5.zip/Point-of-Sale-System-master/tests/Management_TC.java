import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class Management_TC {
    private Management management;
    
    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Before
    public void setUp() throws Exception {
        management = new Management();
        // Create a temporary database file for testing
        File dbFile = tempFolder.newFile("testUserDatabase.txt");
        // Use reflection to set the userDatabase field
        java.lang.reflect.Field field = Management.class.getDeclaredField("userDatabase");
        field.setAccessible(true);
        field.set(null, dbFile.getAbsolutePath());
        
        // Initialize the database with some test data
        try (PrintWriter writer = new PrintWriter(new FileWriter(dbFile))) {
            writer.println("Phone ReturnItems");
            writer.println("1234567890 1,05/15/24,false 2,05/20/24,true");
            writer.println("9876543210");
        }
    }

    @Test
    public void testCheckUserExistingUser() {
        assertTrue(management.checkUser(1234567890L));
    }

    @Test
    public void testCheckUserNonExistingUser() {
        assertFalse(management.checkUser(1111111111L));
    }

    @Test
    public void testCheckUserEmptyFile() throws Exception {
        // Clear the file
        File dbFile = new File(Management.class.getDeclaredField("userDatabase").get(null).toString());
        new PrintWriter(dbFile).close();
        assertFalse(management.checkUser(1234567890L));
    }

    @Test
    public void testGetLatestReturnDateWithOutstandingReturns() {
        List<ReturnItem> returns = management.getLatestReturnDate(1234567890L);
        assertFalse(returns.isEmpty());
        assertEquals(1, returns.get(0).getItemID());
    }

    @Test
    public void testGetLatestReturnDateNoOutstandingReturns() {
        List<ReturnItem> returns = management.getLatestReturnDate(9876543210L);
        assertTrue(returns.isEmpty());
    }

    @Test
    public void testGetLatestReturnDateNonExistingUser() {
        List<ReturnItem> returns = management.getLatestReturnDate(1111111111L);
        assertTrue(returns.isEmpty());
    }

    @Test
    public void testCreateUserNewUser() {
        assertTrue(management.createUser(5555555555L));
        assertTrue(management.checkUser(5555555555L));
    }

    @Test
    public void testCreateUserExistingUser() {
        assertTrue(management.createUser(3333333333L));
        assertTrue(management.createUser(3333333333L)); // Should still return true even if user exists
    }

    @Test
    public void testAddRentalNewRental() throws Exception {
        List<Item> rentalList = new ArrayList<>();
        rentalList.add(new Item(3, "Item3", 20.0f, 1));
        management.addRental(1234567890L, rentalList);
        
        List<ReturnItem> returns = management.getLatestReturnDate(1234567890L);
        assertEquals(2, returns.size()); // Now should have 2 outstanding returns
    }

    @Test
    public void testAddRentalNonExistingUser() throws Exception {
        List<Item> rentalList = new ArrayList<>();
        rentalList.add(new Item(4, "Item4", 25.0f, 1));
        management.addRental(7777777777L, rentalList);
        
        assertTrue(management.checkUser(7777777777L)); // User should be created
        List<ReturnItem> returns = management.getLatestReturnDate(7777777777L);
        assertEquals(1, returns.size());
    }

    @Test
    public void testUpdateRentalStatusReturnItem() throws Exception {
        List<ReturnItem> returnedList = new ArrayList<>();
        returnedList.add(new ReturnItem(1, 0));
        management.updateRentalStatus(1234567890L, returnedList);
        
        List<ReturnItem> returns = management.getLatestReturnDate(1234567890L);
        assertTrue(returns.isEmpty()); // All items should now be returned
    }

    @Test
    public void testUpdateRentalStatusNonExistingUser() throws Exception {
        List<ReturnItem> returnedList = new ArrayList<>();
        returnedList.add(new ReturnItem(5, 0));
        management.updateRentalStatus(8888888888L, returnedList);
        
        // Should not throw an exception, but also should not modify the database
        assertFalse(management.checkUser(8888888888L));
    }

    @Test
    public void testDaysBetween() throws Exception {
        java.lang.reflect.Method method = Management.class.getDeclaredMethod("daysBetween", Calendar.class);
        method.setAccessible(true);
        
        Calendar pastDate = Calendar.getInstance();
        pastDate.add(Calendar.DAY_OF_YEAR, -5);
        
        int days = (int) method.invoke(management, pastDate);
        assertEquals(5, days);
    }

    @Test
    public void testDaysBetweenFutureDate() throws Exception {
        java.lang.reflect.Method method = Management.class.getDeclaredMethod("daysBetween", Calendar.class);
        method.setAccessible(true);
        
        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DAY_OF_YEAR, 5);
        
        int days = (int) method.invoke(management, futureDate);
        assertEquals(-5, days);
    }

    @Test
    public void testDaysBetweenDifferentYear() throws Exception {
        java.lang.reflect.Method method = Management.class.getDeclaredMethod("daysBetween", Calendar.class);
        method.setAccessible(true);
        
        Calendar pastDate = Calendar.getInstance();
        pastDate.add(Calendar.YEAR, -1);
        pastDate.add(Calendar.DAY_OF_YEAR, -5);
        
        int days = (int) method.invoke(management, pastDate);
        assertTrue(days > 365); // Account for leap years
    }
}