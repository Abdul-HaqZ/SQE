import javax.swing.JFrame;

import org.junit.After;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.awt.Window;

public class RegisterTest {

    @After
    public void tearDown() {
        for (Window window : Window.getWindows()) {
            window.dispose();
        }
    }

    @Test
    public void testMainMethodCreatesLoginInterface() {
        // Call the main method
        Register.main(new String[]{});

        // Wait for the frame to be created and become visible
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Find the Login_Interface frame
        Login_Interface loginFrame = null;
        for (Window window : Window.getWindows()) {
            if (window instanceof Login_Interface) {
                loginFrame = (Login_Interface) window;
                break;
            }
        }

        // Assert that Login_Interface is configured correctly
        if (loginFrame != null) {
            assertTrue("Login_Interface should be visible", loginFrame.isVisible());
            assertEquals("Default close operation should be DISPOSE_ON_CLOSE", 
                         JFrame.DISPOSE_ON_CLOSE, loginFrame.getDefaultCloseOperation());
        } else {
            assertTrue("Login_Interface should be created", false);
        }
    }
}