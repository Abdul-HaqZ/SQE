import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.io.*;
import java.util.Calendar;

public class POSSystem_TC {

    private POSSystem posSystem;
    private static final String EMPLOYEE_DB_PATH = "Database/employeeDatabase.txt"; // Adjust path as necessary
    private static final String LOG_FILE_PATH = "Database/employeeLogfile.txt"; // Adjust path as necessary
    private static final String TEMP_FILE_PATH = "Database/temp.txt"; // Adjust path as necessary

    @Before
    public void setUp() throws IOException {
        posSystem = new POSSystem();
        setUpEmployeeDatabase();
    }

    @Test
    public void testLogInSuccess() {
        int result = posSystem.logIn("john_doe", "password123"); // Assume valid username and password
        assertEquals(1, result); // Expecting cashier status
    }

    @Test
    public void testLogInInvalidUsername() {
        int result = posSystem.logIn("invalid_user", "password123");
        assertEquals(0, result); // Invalid username
    }

    @Test
    public void testLogInInvalidPassword() {
        int result = posSystem.logIn("john_doe", "wrong_password");
        assertEquals(0, result); // Invalid password
    }

    @Test
    public void testLogInEmptyUsername() {
        int result = posSystem.logIn("", "password123");
        assertEquals(0, result); // Empty username
    }

    @Test
    public void testLogInEmptyPassword() {
        int result = posSystem.logIn("john_doe", "");
        assertEquals(0, result); // Empty password
    }

    @Test
    public void testLogOut() throws IOException {
        posSystem.logIn("john_doe", "password123"); // Log in first
        posSystem.logOut("Cashier");

        // Check the log file for the logout entry
        BufferedReader reader = new BufferedReader(new FileReader(LOG_FILE_PATH));
        String line;
        boolean foundLogout = false;
        while ((line = reader.readLine()) != null) {
            if (line.contains("logs out of POS System")) {
                foundLogout = true;
                break;
            }
        }
        reader.close();
        assertTrue("Logout entry should be logged", foundLogout);
    }

    @Test
    public void testCheckTempFileExists() throws IOException {
        setUpTempFile("Sale\n");
        assertTrue("Temp file should exist", posSystem.checkTemp());
    }

    @Test
    public void testCheckTempFileNotExists() {
        File tempFile = new File(TEMP_FILE_PATH);
        tempFile.delete(); // Ensure temp file does not exist
        assertFalse("Temp file should not exist", posSystem.checkTemp());
    }

    @Test
    public void testContinueFromTemp() throws IOException {
        setUpTempFile("Sale\n");
        long testPhone = 1234567890L; // Valid phone number
        String result = posSystem.continueFromTemp(testPhone);
        assertEquals("Sale", result); // Expecting to return "Sale"
    }

    @Test
    public void testContinueFromTempEmptyFile() throws IOException {
        setUpTempFile(""); // Now the temp file is empty
        long testPhone = 1234567890L; // Valid phone number
        String result = posSystem.continueFromTemp(testPhone);
        assertEquals("", result); // Expecting to return an empty string
    }

    @Test
    public void testContinueFromTempInvalidPhone() throws IOException {
        setUpTempFile("Sale\n");
        long invalidPhone = -1L; // Invalid phone number for testing
        String result = posSystem.continueFromTemp(invalidPhone);
        assertEquals("", result); // Expecting to return an empty string due to invalid phone
    }

 //   @Test
 //   public void testReadFileFileNotFound() {
 //       String originalPath = POSSystem.employeeDatabase; // Save original path
 //       POSSystem.employeeDatabase = "invalid/path/to/employeeDatabase.txt"; // Set an invalid path
 //       posSystem.readFile(); // Call the method
  //      POSSystem.employeeDatabase = originalPath; // Restore original path
  //  }

  //  @Test
   // public void testReadFileIOException() throws IOException {
    //    File file = new File(EMPLOYEE_DB_PATH);
      //  file.setReadable(false); // Simulate the file being unreadable
      //  posSystem.readFile(); // Call the method
       // file.setReadable(true); // Restore readability
   // }

    @Test
    public void testLogInToFileSuccess() throws IOException {
        posSystem.logIn("john_doe", "password123"); // Successful login
        BufferedReader reader = new BufferedReader(new FileReader(LOG_FILE_PATH));
        String line;
        boolean foundLogin = false;
        while ((line = reader.readLine()) != null) {
            if (line.contains("logs into POS System")) {
                foundLogin = true;
                break;
            }
        }
        reader.close();
        assertTrue("Login entry should be logged", foundLogin);
    }

    @Test
    public void testLogOutToFileSuccess() throws IOException {
        posSystem.logIn("john_doe", "password123"); // Log in first
        posSystem.logOut("Cashier"); // Then log out

        BufferedReader reader = new BufferedReader(new FileReader(LOG_FILE_PATH));
        String line;
        boolean foundLogout = false;
        while ((line = reader.readLine()) != null) {
            if (line.contains("logs out of POS System")) {
                foundLogout = true;
                break;
            }
        }
        reader.close();
        assertTrue("Logout entry should be logged", foundLogout);
    }

    @Test
    public void testLogInMaxLength() {
        // Test with maximum length for username and password
        String longUsername = "a".repeat(255);
        String longPassword = "p".repeat(255);
        int result = posSystem.logIn(longUsername, longPassword);
        assertEquals(0, result); // Expecting failure due to length
    }

  //  @Test
  //  public void testLogInToFileFileNotFound() {
  //     // Assuming the path is incorrect
  //      String originalPath = "Database/employeeLogfile.txt"; // Save original path
  //      posSystem.logInToFile("john_doe", "John Doe", "Cashier", Calendar.getInstance());
  //      // Check if log file has been created or handled properly
  //  }

    @Test
    public void testContinueFromTempInvalidType() throws IOException {
        setUpTempFile("InvalidType\n"); // Set up a temp file with invalid data
        String result = posSystem.continueFromTemp(1234567890L); // Call method
        assertEquals("", result); // Expecting to return an empty string
    }

    @Test
    public void testContinueFromTempFileDoesNotExist() {
        File tempFile = new File(TEMP_FILE_PATH);
        tempFile.delete(); // Ensure temp file does not exist
        String result = posSystem.continueFromTemp(1234567890L); // Call method
        assertEquals("", result); // Expecting to return an empty string
    }

    @Test
    public void testContinueFromTempCorruptedData() throws IOException {
        setUpTempFile("CorruptedData\n");
        String result = posSystem.continueFromTemp(1234567890L);
        assertEquals("", result); // Expecting to return an empty string
    }

  //  @Test
 //   public void testReadFileWhileMissing() {
  //      File file = new File(EMPLOYEE_DB_PATH);
  //      file.delete(); // Delete the file
  //      posSystem.readFile(); // Attempt to read the missing file
        // Check for handling of missing file appropriately (perhaps through logging or exceptions)
  //  }

    @Test
    public void testLogOutWithoutLogin() {
        posSystem.logOut("Cashier"); // Log out without being logged in
        // Verify that no error is thrown or check log file for unexpected entries
    }

    @Test
    public void testLogInLongPassword() {
        String longPassword = "a".repeat(100); // Long password
        int result = posSystem.logIn("john_doe", longPassword);
        assertEquals(0, result); // Expecting failure, depending on your logic
    }

    @Test
    public void testMultipleLogins() {
        posSystem.logIn("john_doe", "password123");
        posSystem.logOut("Cashier");
        int result = posSystem.logIn("john_doe", "password123");
        assertEquals(1, result); // Expecting cashier status again
    }

    // Helper methods for setting up the environment for tests

    private void setUpEmployeeDatabase() throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(EMPLOYEE_DB_PATH));
        writer.write("john_doe John Doe password123 Cashier\n");
        writer.write("jane_smith Jane Smith password456 Admin\n");
        writer.close();
    }

    private void setUpTempFile(String content) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(TEMP_FILE_PATH));
        writer.write(content);
        writer.close();
    }
}
