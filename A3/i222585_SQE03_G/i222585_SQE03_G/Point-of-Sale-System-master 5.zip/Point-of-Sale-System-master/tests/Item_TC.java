import static org.junit.Assert.*;
import org.junit.Test;

public class Item_TC {

    @Test
    public void testItemConstructorAndGetters() {
        // Arrange
        int itemId = 1;
        String itemName = "Test Item";
        float price = 10.5f;
        int amount = 5;

        // Act
        Item item = new Item(itemId, itemName, price, amount);

        // Assert
        assertEquals(itemId, item.getItemID());
        assertEquals(itemName, item.getItemName());
        assertEquals(price, item.getPrice(), 0.01);
        assertEquals(amount, item.getAmount());
    }

    @Test
    public void testUpdateAmount() {
        // Arrange
        Item item = new Item(1, "Test Item", 10.5f, 5);
        
        // Act
        item.updateAmount(10); // Update to 10 items

        // Assert
        assertEquals(10, item.getAmount()); // Check if amount is updated correctly
    }
    
    @Test
    public void testUpdateAmountToZero() {
        // Arrange
        Item item = new Item(2, "Another Item", 15.0f, 3);
        
        // Act
        item.updateAmount(0); // Update to 0 items

        // Assert
        assertEquals(0, item.getAmount()); // Check if amount is updated correctly to zero
    }

    @Test
    public void testUpdateAmountNegativeValue() {
        // Arrange
        Item item = new Item(3, "Negative Item", 5.0f, 5);
        
        // Act
        item.updateAmount(-2); // Update to -2 items

        // Assert
        assertEquals(-2, item.getAmount()); // Check if amount is updated correctly to negative
    }
}
