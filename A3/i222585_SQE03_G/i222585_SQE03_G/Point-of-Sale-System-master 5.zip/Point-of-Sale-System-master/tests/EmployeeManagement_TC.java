import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

import java.io.*;
import java.lang.reflect.Method;
import java.text.DateFormat.Field;
import java.util.*;

public class EmployeeManagement_TC {

    EmployeeManagement empMgmt;
    private static final String TEST_DATABASE = "testEmployeeDatabase.txt";

    @Before
    public void setUp() {
        empMgmt = new EmployeeManagement();

        // Set up test data and initialize the employee list
        empMgmt.employees = new ArrayList<>(Arrays.asList(
            new Employee("1", "John Doe", "Admin", "pass123"),
            new Employee("2", "Jane Smith", "Cashier", "pass456")
        ));

        // Write test data to a test database file
        writeTestFile(TEST_DATABASE, empMgmt.employees);

        // Use reflection to set the private static `EMPLOYEE_DATABASE` to the test file
        try {
            java.lang.reflect.Field databaseField = EmployeeManagement.class.getDeclaredField("EMPLOYEE_DATABASE");
            databaseField.setAccessible(true);
            databaseField.set(null, TEST_DATABASE);
        } catch (Exception e) {
            fail("Failed to set EMPLOYEE_DATABASE to test file: " + e.getMessage());
        }
    }

    @After
    public void tearDown() {
        // Clean up test file after each test
        File file = new File(TEST_DATABASE);
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    public void testGetEmployeeList() {
        List<Employee> employees = empMgmt.getEmployeeList();
        assertEquals(2, employees.size());
        assertEquals("John Doe", employees.get(0).getName());
        assertEquals("Jane Smith", employees.get(1).getName());
    }

    @Test
    public void testAddEmployee() {
        empMgmt.add("Mike Ross", "pass789", true); // Add a cashier
        empMgmt.add("Harvey Specter", "pass101", false); // Add an admin

        List<Employee> employees = empMgmt.getEmployeeList();
        assertEquals(4, employees.size());
        assertEquals("Cashier", employees.get(2).getPosition());
        assertEquals("Admin", employees.get(3).getPosition());

        // Test for empty employees list
        empMgmt.employees.clear();
        empMgmt.add("New Employee", "newpass", true);
        assertEquals(1, empMgmt.getEmployeeList().size()); // Test after adding to an empty list
    }

    @Test
    public void testDeleteEmployee() {
        boolean deleted = empMgmt.delete("1");
        assertTrue(deleted);

        List<Employee> employees = empMgmt.getEmployeeList();
        assertEquals(1, employees.size());
        assertEquals("Jane Smith", employees.get(0).getName());

        // Test deletion of a non-existing employee
        assertFalse(empMgmt.delete("10"));
    }

    @Test
    public void testUpdateEmployee() {
        // Successful update
        int result = empMgmt.update("1", "newpass", "Admin", "John Updated");
        assertEquals(0, result);

        Employee updated = empMgmt.getEmployeeList().get(0);
        assertEquals("John Updated", updated.getName());
        assertEquals("newpass", updated.getPassword());

        // Update with invalid position
        int invalidPosition = empMgmt.update("1", "newpass", "Manager", "");
        assertEquals(-2, invalidPosition);

        // Try to update non-existing employee
        int notFound = empMgmt.update("10", "newpass", "Admin", "");
        assertEquals(-1, notFound);

        // Test updating only password
        empMgmt.update("1", "passwordOnly", "", "");
        assertEquals("passwordOnly", empMgmt.getEmployeeList().get(0).getPassword());

        // Test updating only position
        empMgmt.update("1", "", "Cashier", "");
        assertEquals("Cashier", empMgmt.getEmployeeList().get(0).getPosition());

        // Test updating only name
        empMgmt.update("1", "", "", "John NewName");
        assertEquals("John NewName", empMgmt.getEmployeeList().get(0).getName());
    }

    @Test
    public void testReadFile() {
        try {
            // Access the private readFile method using reflection
            Method readFileMethod = EmployeeManagement.class.getDeclaredMethod("readFile");
            readFileMethod.setAccessible(true);  // Make the private method accessible

            // Invoke the readFile method
            readFileMethod.invoke(empMgmt);

            // After invoking, get the employee list and validate
            List<Employee> employees = empMgmt.getEmployeeList();
            assertEquals(2, employees.size());
            assertEquals("John Doe", employees.get(0).getName());
            assertEquals("Jane Smith", employees.get(1).getName());

        } catch (Exception e) {
            fail("Exception occurred during readFile invocation: " + e.getMessage());
        }
    }

    @Test
    public void testFileNotFound() {
        // Simulate FileNotFoundException by providing an incorrect file path
        try {
            java.lang.reflect.Field databaseField = EmployeeManagement.class.getDeclaredField("EMPLOYEE_DATABASE");
            databaseField.setAccessible(true);
            databaseField.set(null, "nonExistingFile.txt");

            List<Employee> employees = empMgmt.getEmployeeList();
            assertEquals(0, employees.size()); // No employees should be found, empty list expected

        } catch (Exception e) {
            fail("Exception occurred while testing non-existing file: " + e.getMessage());
        }
    }

    @Test
    public void testIOExceptionDuringWrite() {
        // Simulate IOException by making the file read-only
        File file = new File(TEST_DATABASE);
        file.setReadOnly();

        // Test that add, update, or delete fails gracefully
        try {
            empMgmt.add("Test", "testpass", true);
            fail("Expected IOException due to read-only file");
        } catch (Exception e) {
            assertTrue(e instanceof IOException); // Ensure that an IOException is thrown
        } finally {
            file.setWritable(true); // Restore the file to be writable for subsequent tests
        }
    }

    private void writeTestFile(String filename, List<Employee> employees) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Employee emp : employees) {
                writer.write(emp.getUsername() + " " + emp.getPosition() + " " + emp.getName() + " " + emp.getPassword());
                writer.newLine();
            }
        } catch (IOException e) {
            fail("Failed to write test employee database file: " + e.getMessage());
        }
    }
}
