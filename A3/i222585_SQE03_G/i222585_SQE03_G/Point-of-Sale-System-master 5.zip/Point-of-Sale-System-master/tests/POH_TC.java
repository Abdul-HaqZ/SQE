import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.io.*;
import java.util.ArrayList;

public class POH_TC {

    private POH poh;
    private final String tempFile = "Database/temp.txt";
    private final String newTempFile = "Database/newTemp.txt";
    private final String returnSaleFile = "Database/returnSale.txt";
    private final String textFile = "Database/textFile.txt";

    @Before
    public void setUp() throws IOException {
        // Initialize the POH object before each test
        poh = new POH(1234567890L);
        
        // Create a temporary file for testing
        File file = new File(tempFile);
        file.getParentFile().mkdirs();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("type\n");
            writer.write("1234567890\n");
            writer.write("1 2\n");
        }
    }

    @After
    public void tearDown() {
        // Clean up after each test
        File file = new File(tempFile);
        if (file.exists()) {
            file.delete();
        }
        File newFile = new File(newTempFile);
        if (newFile.exists()) {
            newFile.delete();
        }
        File returnFile = new File(returnSaleFile);
        if (returnFile.exists()) {
            returnFile.delete();
        }
    }

    @Test
    public void testDefaultConstructor() {
        POH defaultPoh = new POH();
        assertEquals(0, defaultPoh.phone);
    }

    @Test
    public void testParameterizedConstructor() {
        assertEquals(1234567890L, poh.phone);
    }

    @Test
    public void testDeleteTempItem() throws IOException {
        // Add a transaction item to the list
        poh.transactionItem = new ArrayList<>();
        poh.transactionItem.add(new Item(1, "ItemName", 10, 2));

        // Call the deleteTempItem method
        poh.deleteTempItem(1);

        // Verify the temporary file content
        try (BufferedReader reader = new BufferedReader(new FileReader(tempFile))) {
            assertEquals("type", reader.readLine());
            assertEquals("1234567890", reader.readLine());
            assertNull(reader.readLine());
        }
    }

    @Test
    public void testDeleteTempItem_FileNotFound() {
        // Delete the temp file to simulate FileNotFoundException
        File file = new File(tempFile);
        file.delete();

        // Call the deleteTempItem method
        poh.deleteTempItem(1);

        // Verify the console output (manually check for "Unable to open file 'temp'")
    }

    @Test
    public void testDeleteTempItem_IOException() throws IOException {
        // Create a read-only temp file to simulate IOException
        File file = new File(tempFile);
        file.setReadOnly();

        // Call the deleteTempItem method
        poh.deleteTempItem(1);

        // Verify the console output (manually check for "Error reading file 'temp'")

        // Reset file permissions
        file.setWritable(true);
    }

    @Test
    public void testEndPOS() throws IOException {
        // Add a transaction item to the list
        poh.transactionItem = new ArrayList<>();
        poh.transactionItem.add(new Item(1, "ItemName", 10, 2));

        // Set returnSale to true
        poh.returnSale = true;

        // Call the endPOS method
        double result = poh.endPOS(textFile);

        // Verify the returnSale file content
        try (BufferedReader reader = new BufferedReader(new FileReader(returnSaleFile))) {
            assertEquals("", reader.readLine());
            assertEquals("1 ItemName 2 20.0", reader.readLine());
        }

        // Verify the total price
        assertEquals(20.0, result, 0.01);
    }

    @Test
    public void testRetrieveTemp() throws IOException {
        // Call the retrieveTemp method
        poh.retrieveTemp(tempFile);

        // Verify the transaction item list
        assertEquals(1, poh.transactionItem.size());
        assertEquals(1, poh.transactionItem.get(0).getItemID());
        assertEquals(2, poh.transactionItem.get(0).getAmount());
    }
}